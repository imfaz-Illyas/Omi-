// OMI LANKA service worker: app shell offline (bots mode works without internet).
const V='omi-v1';
const SHELL=['/','/css/app.css?v=1','/js/app.js?v=1','/manifest.webmanifest','/icons/icon-192.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(e.request.method!=='GET'||u.origin!==location.origin||u.pathname.startsWith('/ws')||u.pathname.startsWith('/api'))return;
  if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match('/')));return}
  e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(res=>{if(res.ok&&/^\/(css|js|icons)\//.test(u.pathname)){const c=res.clone();caches.open(V).then(x=>x.put(e.request,c))}return res})));
});
