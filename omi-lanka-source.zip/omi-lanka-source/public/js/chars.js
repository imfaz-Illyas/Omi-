// OMI LANKA – the four original characters and their emotes, drawn as SVG.
(()=>{
const INK='#2a1a12';
const CHARS={
  kasun:  {skin:'#b9784a',hair:'#22150e',bg:'#5fb3ff',names:['කසුන්','Kasun','Kasun'],girl:false},
  dilini: {skin:'#d9a072',hair:'#3a2216',bg:'#ff8fb1',names:['දිලිනි','Dilini','Dilini'],girl:true},
  nuwan:  {skin:'#a8673a',hair:'#1c120c',bg:'#ffb347',names:['නුවන්','Nuwan','Nuwan'],girl:false},
  sachini:{skin:'#c88a5a',hair:'#2e1a10',bg:'#7bd389',names:['සචිනි','Sachini','Sachini'],girl:true}
};
const EMOTES=['sad','wow','nice','goodjob','lol','angry','love','thinking'];
const EMOJI={sad:'😢',wow:'😲',nice:'😎',goodjob:'🏆',lol:'😂',angry:'😡',love:'❤️',thinking:'🤔'};
function shade(hex,f){const n=parseInt(hex.slice(1),16);let r=n>>16,g=(n>>8)&255,b=n&255;
  const m=v=>Math.max(0,Math.min(255,Math.round(f<0?v*(1+f):v+(255-v)*f)));return'#'+[m(r),m(g),m(b)].map(v=>v.toString(16).padStart(2,'0')).join('')}
const shades=(y,op)=>`<g opacity="${op||1}"><rect x="31" y="${y-5.5}" width="16" height="11" rx="5" fill="#111"/><rect x="53" y="${y-5.5}" width="16" height="11" rx="5" fill="#111"/><path d="M47 ${y-1} Q50 ${y-3} 53 ${y-1}" stroke="#111" stroke-width="2" fill="none"/><path d="M34 ${y-2} l5 -2 M56 ${y-2} l5 -2" stroke="#fff" stroke-width="1.6" opacity=".7" stroke-linecap="round"/></g>`;
function body(id,c){
  const sh=id==='kasun'?'#2f6fd6':id==='dilini'?'#fdfdfd':id==='nuwan'?'#8e1b2b':'#ffc928';
  let s=`<path d="M10 100 Q12 79 35 74 L65 74 Q88 79 90 100 Z" fill="${sh}" stroke="${INK}" stroke-width="1.5"/>`;
  if(id==='kasun')s+=`<g><circle cx="24" cy="88" r="4" fill="#ffd23f"/><circle cx="24" cy="88" r="1.5" fill="#ff8c42"/><circle cx="76" cy="90" r="4.5" fill="#ff8c42"/><circle cx="76" cy="90" r="1.6" fill="#ffd23f"/><circle cx="36" cy="97" r="3" fill="#ffd23f"/><circle cx="66" cy="80" r="2.6" fill="#ffd23f"/><path d="M44 74 L50 84 L56 74" fill="#2459b0" stroke="${INK}" stroke-width="1.2"/></g>`;
  if(id==='dilini')s+=`<path d="M40 74 Q50 86 60 74" fill="${shade(c.skin,-.08)}" stroke="${INK}" stroke-width="1.2"/>`;
  if(id==='nuwan')s+=`<path d="M41 74 Q50 81 59 74" fill="none" stroke="#5e0f1b" stroke-width="2"/><rect x="62" y="84" width="11" height="7" rx="1" fill="#ffbe29" stroke="${INK}" stroke-width=".8"/><rect x="63.5" y="85.2" width="2.5" height="4.6" fill="#00534e"/><rect x="66.6" y="85.2" width="5.6" height="4.6" fill="#8d153a"/>`;
  if(id==='sachini')s+=`<path d="M38 75 Q50 88 62 75" fill="${shade(c.skin,-.08)}" stroke="${INK}" stroke-width="1.2"/><path d="M42 80 Q50 85 58 80" stroke="#e0a800" stroke-width="1.4" fill="none"/>`;
  return s;
}
function hairBack(id,c){
  if(id==='dilini')return`<path d="M22 42 Q16 12 50 12 Q84 12 78 42 Q88 64 82 90 Q72 84 72 66 L28 66 Q28 84 18 90 Q12 64 22 42Z" fill="${c.hair}" stroke="${INK}" stroke-width="1.2"/><path d="M20 60 Q16 70 20 80 M80 60 Q84 70 80 80" stroke="${shade(c.hair,.2)}" stroke-width="2" fill="none"/>`;
  if(id==='sachini')return`<circle cx="50" cy="13" r="11" fill="${c.hair}" stroke="${INK}" stroke-width="1.2"/><circle cx="42" cy="9" r="5" fill="${c.hair}"/><circle cx="58" cy="9" r="5" fill="${c.hair}"/><circle cx="24" cy="44" r="7" fill="${c.hair}"/><circle cx="76" cy="44" r="7" fill="${c.hair}"/><circle cx="23" cy="56" r="5.5" fill="${c.hair}"/><circle cx="77" cy="56" r="5.5" fill="${c.hair}"/>`;
  return'';
}
function hairFront(id,c){
  if(id==='kasun')return`<g fill="${c.hair}" stroke="${INK}" stroke-width="1"><circle cx="30" cy="34" r="7"/><circle cx="36" cy="25" r="8"/><circle cx="46" cy="20" r="8.5"/><circle cx="57" cy="20" r="8.5"/><circle cx="66" cy="25" r="8"/><circle cx="71" cy="34" r="7"/></g><path d="M27 40 Q50 26 73 40 Q70 30 50 28 Q31 30 27 40Z" fill="${c.hair}"/>`;
  if(id==='nuwan')return`<path d="M27 46 Q22 22 44 16 Q60 11 72 22 Q78 30 74 46 Q71 34 60 31 Q48 34 34 33 Q29 37 27 46Z" fill="${c.hair}" stroke="${INK}" stroke-width="1.2"/><path d="M44 16 Q54 6 66 14" fill="${c.hair}" stroke="${INK}" stroke-width="1.2"/>`;
  if(id==='dilini')return`<path d="M26 46 Q28 20 52 20 Q74 21 75 46 Q68 30 54 30 Q40 31 26 46Z" fill="${c.hair}" stroke="${INK}" stroke-width="1.2"/>`;
  if(id==='sachini')return`<path d="M26 46 Q26 23 50 22 Q74 23 74 46 Q67 32 50 31 Q34 32 26 46Z" fill="${c.hair}" stroke="${INK}" stroke-width="1.2"/><circle cx="34" cy="29" r="4.5" fill="${c.hair}"/><circle cx="66" cy="29" r="4.5" fill="${c.hair}"/>`;
  return'';
}
function beard(id,c){
  if(id==='kasun')return`<path d="M27 50 Q28 75 50 77 Q72 75 73 50 Q68 64 58 63 Q50 60 42 63 Q32 64 27 50Z" fill="${c.hair}" stroke="${INK}" stroke-width="1"/>`;
  if(id==='nuwan')return`<path d="M28 52 Q30 73 50 75 Q70 73 72 52 Q66 63 57 63 Q50 61 43 63 Q34 63 28 52Z" fill="${c.hair}" opacity=".85"/>`;
  return'';
}
function eyes(e,c){
  const lid=c.hair;
  const open=(dx=0,dy=0,rx=4.6,ry=5.2,pr=2.7)=>[41,59].map(x=>`<ellipse cx="${x}" cy="47" rx="${rx}" ry="${ry}" fill="#fff" stroke="${INK}" stroke-width="1.1"/><circle cx="${x+dx}" cy="${47+dy}" r="${pr}" fill="${INK}"/><circle cx="${x+dx+.9}" cy="${46+dy}" r=".9" fill="#fff"/>`).join('');
  const arc=(up)=>[41,59].map(x=>`<path d="M${x-5} ${up?49:46} Q${x} ${up?43:51} ${x+5} ${up?49:46}" stroke="${INK}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`).join('');
  const heart=(x,y,s,col)=>`<path d="M${x} ${y+s*.9} C${x-s*1.6} ${y-s*.1} ${x-s*.9} ${y-s*1.3} ${x} ${y-s*.45} C${x+s*.9} ${y-s*1.3} ${x+s*1.6} ${y-s*.1} ${x} ${y+s*.9}Z" fill="${col}" stroke="${INK}" stroke-width=".9"/>`;
  switch(e){
    case'sad':return open(0,1.6,4.4,4.6,2.6)+`<path d="M36 44.5 Q41 46.5 46 44.5 M54 44.5 Q59 46.5 64 44.5" stroke="${shade(c.skin,-.25)}" stroke-width="1.6" fill="none"/><path d="M37 53 Q35 58 37.5 60 Q40 58 37 53Z" fill="#6cc4ff" stroke="#2b88c9" stroke-width=".6"/>`;
    case'wow':return open(0,0,5.8,6.8,2.3);
    case'nice':return shades(47);
    case'goodjob':return arc(true);
    case'lol':return`<path d="M36 44 L44.5 47.5 L36 51 M64 44 L55.5 47.5 L64 51" stroke="${INK}" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M31 50 Q27 56 30 60 Q34 57 31 50Z M69 50 Q73 56 70 60 Q66 57 69 50Z" fill="#6cc4ff" stroke="#2b88c9" stroke-width=".6"/>`;
    case'angry':return open(-.8,.6,4.4,4.4,2.6)+`<path d="M36 43 L46 46 L46 43Z M64 43 L54 46 L54 43Z" fill="${c.skin}"/>`;
    case'love':return heart(41,47,5.2,'#ff3b5c')+heart(59,47,5.2,'#ff3b5c');
    case'thinking':return open(1.6,-1.6);
    default:return open();
  }
}
function brows(e,c){
  const B=(d)=>`<path d="${d}" stroke="${c.hair}" stroke-width="2.8" fill="none" stroke-linecap="round"/>`;
  switch(e){
    case'sad':return B('M35 40 Q40 39 46 36')+B('M65 40 Q60 39 54 36');
    case'wow':return B('M34 36 Q40 31 46 34')+B('M54 34 Q60 31 66 36');
    case'angry':return B('M34 35 L46 41')+B('M66 35 L54 41');
    case'thinking':return B('M35 40 Q40 38 46 40')+B('M54 35 Q60 31 66 34');
    case'nice':return B('M34 38 Q40 36 46 38')+B('M54 38 Q60 36 66 38');
    default:return B('M35 39 Q40 36 46 38')+B('M54 38 Q60 36 65 39');
  }
}
function mouth(e){
  switch(e){
    case'sad':return`<path d="M43 65 Q50 59 57 65" stroke="${INK}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`;
    case'wow':return`<ellipse cx="50" cy="64" rx="4.6" ry="5.6" fill="#5a1414" stroke="${INK}" stroke-width="1.2"/>`;
    case'nice':return`<path d="M42 62 Q51 67 59 59" stroke="${INK}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`;
    case'goodjob':return`<path d="M39 59 Q50 74 61 59 Z" fill="#fff" stroke="${INK}" stroke-width="1.6" stroke-linejoin="round"/><path d="M41 61 Q50 64 59 61" stroke="${INK}" stroke-width=".8" fill="none"/>`;
    case'lol':return`<path d="M37 57 Q50 79 63 57 Z" fill="#5a1414" stroke="${INK}" stroke-width="1.6" stroke-linejoin="round"/><path d="M39 58 Q50 62 61 58 L60.5 60 Q50 63.5 39.5 60Z" fill="#fff"/><ellipse cx="50" cy="69" rx="5" ry="3" fill="#ff7a8a"/>`;
    case'angry':return`<rect x="41" y="59" width="18" height="7.5" rx="2.5" fill="#fff" stroke="${INK}" stroke-width="1.6"/><path d="M45.5 59v7.5M50 59v7.5M54.5 59v7.5M41 62.8h18" stroke="${INK}" stroke-width=".9"/>`;
    case'love':return`<path d="M42 60 Q50 70 58 60 Z" fill="#c2253d" stroke="${INK}" stroke-width="1.4" stroke-linejoin="round"/>`;
    case'thinking':return`<path d="M44 64 Q47 62 50 63.5 Q53 65 56 62" stroke="${INK}" stroke-width="2.2" fill="none" stroke-linecap="round"/>`;
    default:return`<path d="M42 60 Q50 68 58 60" stroke="${INK}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`;
  }
}
function extras(e,c){
  const heart=(x,y,s)=>`<path d="M${x} ${y+s*.9} C${x-s*1.6} ${y-s*.1} ${x-s*.9} ${y-s*1.3} ${x} ${y-s*.45} C${x+s*.9} ${y-s*1.3} ${x+s*1.6} ${y-s*.1} ${x} ${y+s*.9}Z" fill="#ff3b5c" stroke="#fff" stroke-width="1"/>`;
  switch(e){
    case'wow':return`<g stroke="#ffd23f" stroke-width="2.6" stroke-linecap="round"><path d="M14 22 L20 26 M10 34 L17 35 M86 22 L80 26 M90 34 L83 35"/></g>`;
    case'goodjob':return`<g transform="translate(71 60) scale(.82)"><path d="M3 2 H23 V8 Q23 17 13 18 Q3 17 3 8Z" fill="#ffd23f" stroke="${INK}" stroke-width="1.3"/><path d="M3 5 Q-3 5 0 11 Q2 13 4 12 M23 5 Q29 5 26 11 Q24 13 22 12" fill="none" stroke="${INK}" stroke-width="1.3"/><rect x="10" y="18" width="6" height="5" fill="#f0b400" stroke="${INK}" stroke-width="1"/><rect x="6" y="23" width="14" height="5" rx="1" fill="#8b5a2b" stroke="${INK}" stroke-width="1"/><path d="M13 5 l1.6 3.2 3.4.4-2.5 2.3.7 3.4-3.2-1.7-3.2 1.7.7-3.4-2.5-2.3 3.4-.4Z" fill="#fff"/></g>`;
    case'angry':return`<ellipse cx="50" cy="50" rx="23" ry="25" fill="#ff3b30" opacity=".22"/><g transform="translate(74 18)" stroke="#e8202a" stroke-width="2.6" stroke-linecap="round" fill="none"><path d="M0 4 Q4 4 4 0 M8 0 Q8 4 12 4 M12 8 Q8 8 8 12 M4 12 Q4 8 0 8"/></g><g fill="#fff" opacity=".9"><circle cx="16" cy="30" r="4"/><circle cx="11" cy="24" r="3"/></g>`;
    case'love':return heart(82,20,5)+heart(18,28,3.6)+`<ellipse cx="34" cy="56" rx="5" ry="3" fill="#ff6b8a" opacity=".45"/><ellipse cx="66" cy="56" rx="5" ry="3" fill="#ff6b8a" opacity=".45"/>`;
    case'thinking':return`<g fill="#fff" stroke="${INK}" stroke-width="1"><circle cx="76" cy="26" r="2.6"/><circle cx="82" cy="18" r="3.6"/><circle cx="89" cy="9" r="5"/></g><path d="M56 80 Q54 70 60 68 Q66 66 68 72 L70 82 Q66 86 60 86Z" fill="${c.skin}" stroke="${INK}" stroke-width="1.3"/><path d="M60 68 Q58 63 62 61 Q65 61 65 66" fill="${c.skin}" stroke="${INK}" stroke-width="1.3"/>`;
    default:return'';
  }
}
function charInner(id,e){
  const c=CHARS[id];if(!c)return'';e=e||'neutral';
  const ear=shade(c.skin,-.1);
  let s=hairBack(id,c)+body(id,c)+`<rect x="43" y="64" width="14" height="13" fill="${shade(c.skin,-.12)}"/>`;
  s+=`<ellipse cx="27" cy="50" rx="5" ry="6" fill="${ear}" stroke="${INK}" stroke-width="1"/><ellipse cx="73" cy="50" rx="5" ry="6" fill="${ear}" stroke="${INK}" stroke-width="1"/>`;
  if(c.girl)s+=`<circle cx="27" cy="59" r="4" fill="none" stroke="#f4b400" stroke-width="2"/><circle cx="73" cy="59" r="4" fill="none" stroke="#f4b400" stroke-width="2"/>`;
  s+=`<ellipse cx="50" cy="49" rx="23" ry="25" fill="${c.skin}" stroke="${INK}" stroke-width="1.4"/>`;
  s+=beard(id,c)+hairFront(id,c);
  if(c.girl)s+=`<ellipse cx="34" cy="56" rx="4.5" ry="2.6" fill="#ff7b8f" opacity=".3"/><ellipse cx="66" cy="56" rx="4.5" ry="2.6" fill="#ff7b8f" opacity=".3"/>`;
  s+=`<path d="M50 50 Q47.5 55.5 51 56.5" stroke="${shade(c.skin,-.35)}" stroke-width="1.5" fill="none" stroke-linecap="round"/>`;
  const shadesOn=(id==='kasun'&&e==='neutral')||e==='nice';
  if(!shadesOn)s+=eyes(e,c);
  s+=brows(e,c);
  if(shadesOn)s+=shades(47);
  s+=mouth(e);
  if(id==='kasun'&&!shadesOn)s+=shades(26,.95);
  if(id==='dilini'&&e!=='nice')s+=`<g transform="rotate(-6 50 22)">${shades(22)}</g>`;
  s+=extras(e,c);
  return s;
}
function charSVG(id,e){return`<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">${charInner(id,e)}</svg>`}
window.OmiChars={CHARS,EMOTES,EMOJI,charInner,charSVG};
})();
