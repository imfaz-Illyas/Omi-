(()=>{
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

/* ================= STORAGE ================= */
const store={
  get(k,d){try{const v=localStorage.getItem('omilanka:'+k);return v?Object.assign(Array.isArray(d)?[]:{},d,JSON.parse(v)):d}catch(e){return d}},
  set(k,v){try{localStorage.setItem('omilanka:'+k,JSON.stringify(v))}catch(e){}}
};
const S=store.get('settings',{lang:'si',comments:true,sound:true,voice:false,speed:'normal',target:10,kapothi:'3',timer:true});
const P=store.get('profile',{name:'',avatar:'kasun',photo:null});
const ST=store.get('stats',{played:0,wins:0,losses:0,streak:0,best:0,kapothis:0,comebacks:0,whitewash:0});
const saveS=()=>store.set('settings',S), saveP=()=>store.set('profile',P), saveST=()=>store.set('stats',ST);

/* ================= OMI ENGINE (pure, server-portable) ================= */
const SUITS=['S','H','C','D'], RANKS=['7','8','9','10','J','Q','K','A'];
const SYM={S:'♠\uFE0E',H:'♥\uFE0E',D:'♦\uFE0E',C:'♣\uFE0E'};
const RED={H:1,D:1};
function rand(n){const a=new Uint32Array(1);crypto.getRandomValues(a);return a[0]%n}
const Omi={
  deck(){const d=[];for(const s of SUITS)for(const r of RANKS)d.push({s,r,id:r+s});return d},
  shuffle(a){const b=a.slice();for(let i=b.length-1;i>0;i--){const j=rand(i+1);[b[i],b[j]]=[b[j],b[i]]}return b},
  v(c){return RANKS.indexOf(c.r)},
  legal(hand,trick){if(!trick.length)return hand.slice();const led=trick[0].card.s;const f=hand.filter(c=>c.s===led);return f.length?f:hand.slice()},
  isLegal(hand,trick,card){return Omi.legal(hand,trick).some(c=>c.id===card.id)},
  beats(a,b,trump){if(a.s===b.s)return Omi.v(a)>Omi.v(b);return a.s===trump},
  winnerIdx(trick,trump){let w=0;for(let i=1;i<trick.length;i++)if(Omi.beats(trick[i].card,trick[w].card,trump))w=i;return w},
  scoreRound(tricks,callerTeam,cfg){
    if(tricks[0]===tricks[1])return{tie:true};
    const wt=tricks[0]>tricks[1]?0:1, kap=tricks[wt]===8;
    let pts=wt===callerTeam?1:2;
    if(kap){ if(cfg.kapothi==='game')pts=Infinity; else if(cfg.kapothi==='3')pts=3; }
    return{winnerTeam:wt,points:pts,kapothi:kap,byCaller:wt===callerTeam};
  }
};

/* ================= TEXT ================= */
const LI={si:0,sl:1,en:2};
const T={
si:{
  welcome:['ආයුබෝවන්! OMI ගහන්න ලෑස්තිද? 😂','කාඩ් ටික අතට ගන්න, ගේම පටන් ගමු! 🃏','අද කවුද වැඩ්ඩා? බලමුකෝ! 😎','ට්‍රම්ප් එක හරියට තෝරගත්තොත් ගේම අපේ! 🔥','තේ එකක් බීලා ඕමි ගහමු ☕'],
  play:'ගේම පටන් ගමු', playSub:'Bots තුන්දෙනෙක් එක්ක ඉක්මන් ගේමක්', random:'අහඹු අය එක්ක ගහමු', private:'Private Room එකක්', join:'Room එකකට යන්න',
  leaderboard:'ලකුණු', settings:'සැකසුම්', rules:'නීති', profile:'මගේ ප්‍රොෆයිල් එක', nickname:'නම', chooseAvatar:'Avatar එක තෝරන්න',
  upload:'📷 ෆොටෝ එකක් දාන්න', removePhoto:'ෆොටෝ එක අයින් කරන්න', save:'සේව් කරන්න', namePh:'ඔයාගේ නම',
  language:'භාෂාව', comments:'විහිළු කමෙන්ට්ස්', sound:'සද්දය', voice:'සිංහල කටහඬ', voiceNote:'ඔයාගේ device එකේ සිංහල voice එකක් තියෙනවා නම් විතරයි වැඩ කරන්නේ.',
  speed:'Bots ගේ වේගය', slow:'හෙමින්', normal:'සාමාන්‍ය', fast:'වේගෙන්', target:'දිනන්න ඕන ලකුණු', kapothiRule:'කපෝති (අත් 8ම)', kap3:'ලකුණු 3', kapGame:'ගේමම දිනුම්', kapNone:'සාමාන්‍ය ලකුණු',
  kapNote:'ගම්වල නීති වෙනස් වෙන්න පුළුවන් — ඔයාලගේ විදිහට තෝරන්න.', timer:'වාර timer (තත්පර 30)', on:'ඔන්', off:'ඕෆ්', openRules:'📜 නීති බලන්න',
  us:'අපි', them:'එයාලා', trump:'ට්‍රම්ප්', tricks:'අත්', you:'ඔයා',
  yourTurn:'ඔයාගේ වාරය! කාඩ් එකක් දාන්න', yourTurnTouch:'ඔයාගේ වාරය! කාඩ් එක ආයෙත් tap කරන්න නැත්නම් උඩට අදින්න', turnOf:'{n}ගේ වාරය...',
  chooseTrump:'ට්‍රම්ප් එක තෝරන්න', chooseTrumpSub:'ඔයාගේ මුල් කාඩ් 4 බලලා තෝරන්න', choosingTrump:'{n} ට්‍රම්ප් එක තෝරනවා... 🤔',
  trumpIs:'ට්‍රම්ප් එක {s}!', dealing:'කාඩ් බෙදනවා... 🃏', gameStart:'ඔන්න ගේම පටන් ගන්නවා!', followSuit:'අනේ බං, මුලින් දාපු පාටම දාන්න ඕනේ! 😅',
  roundUs:'අපි වටය දිනුවා! 🎉', roundThem:'එයාලා වටය ගත්තා 😩', roundTie:'අත් 4යි 4යි, සමයි! 🤝', kapothiUs:'කපෝති! 🕊️ අත් 8ම අපේ!', kapothiThem:'අම්මෝ, කපෝති කෑවා! 🕊️💀',
  whyCaller:'ට්‍රම්ප් කිව්ව ටීම් එක දිනුවා, ඒ නිසා ලකුණු 1යි.', whyDefender:'ට්‍රම්ප් නොකිව්ව ටීම් එක දිනුවා, ඒ නිසා ලකුණු 2ක්!', whyKap:'අත් 8ම ගත්තා, කපෝති!',
  whyTie:'කාටවත් ලකුණු නෑ. ඊළඟ වටය දිනන ටීම් එකට ලකුණු {c}ක් අමතරව!', carryAdd:'(සම වුණ වටයෙන් +{c})', nextRound:'ඊළඟ වටය ▶',
  weWin:'අපේ ටීම් එක දිනුම්!', theyWin:'එයාලා දිනුවා... 😭', rematch:'ආයෙත් ගහමුද? 🔁', home:'මුල් පිටුවට 🏠', invite:'යාළුවන්ට කියන්න 📨',
  inviteText:'එන්න OMI LANKA ගහමු! 🃏🇱🇰', copied:'ලින්ක් එක කොපි වුණා!',
  onlineTitle:'ඔන්ලයින් ගේම් 🌐', onlineBody:'Private rooms, room codes, invite links, random matchmaking වලට real-time game server එකක් ඕනේ. ඒක තමයි ඊළඟ පියවර (Phase 2). දැනට Bots තුන්දෙනෙක් එක්ක සුපිරි ගේමක් ගහමු!', playBots:'Bots එක්ක ගහමු 🤖',
  statsTitle:'මගේ ලකුණු 🏆', statsNote:'ලෝක ලීඩර්බෝඩ් එක online accounts එක්ක එනවා. දැනට පේන්නේ මේ device එකේ ලකුණු.',
  played:'ගේම්', wins:'දිනුම්', losses:'පැරදුම්', winPct:'දිනුම් %', streak:'දැන් පෙළ', best:'හොඳම පෙළ', kapothis:'කපෝති', awards:'සම්මාන', newAward:'අලුත් සම්මානයක්! {a}',
  quitTitle:'ගේම නවත්තන්නද?', quitBody:'මේ ගේම එකේ ලකුණු නැති වෙනවා.', quitYes:'ඔව්, නවත්තන්න', quitNo:'නෑ, දිගටම ගහමු',
  tricksTaken:'අත් {n}', calledN:'ට්‍රම්ප් {n} වතාවක්', photoErr:'ඒ ෆොටෝ එක ගන්න බැරි වුණා. වෙන එකක් දාලා බලන්න.',
  suit:{S:'ඉස්පේඩ්',H:'හාට්',D:'දියමන්ති',C:'කලාවර්'},
  reacts:{'😢':'දුකයි','😲':'අම්මෝ!','😎':'නියමයි!','🏆':'සුපිරි වැඩක්!','😂':'හිනා යනවා','😡':'කේන්තියි!','❤️':'ආසයි!','🤔':'හිතනවා...'},
  awardsList:{champ:['👑 OMI Champion','ගේම් 10ක් දිනන්න'],unlucky:['😂 අවාසනාවේ රජා','ගේම් 5ක් පරදින්න'],comeback:['🔥 Comeback King','ලකුණු 5ක් පස්සෙන් ඉඳලා දිනන්න'],loser:['💀 Biggest Loser','ලකුණක්වත් නැතුව පරදින්න'],master:['🎯 Card Master','කපෝතියක් ගහන්න'],legend:['🃏 OMI Legend','ගේම් 50ක් ගහන්න']},
  rulesTitle:'ඕමි නීති 📜',
  rulesBody:'<ul><li>කාඩ් <b>32</b>යි. හැම පාටකින්ම 7 ඉඳන් A දක්වා. ලොකුම <b>A</b>, ඊළඟට K, Q, J, 10, 9, 8, පොඩිම <b>7</b>.</li><li>සෙල්ලම් කරන්නේ හතර දෙනයි, ටීම් දෙකයි. ඔයාගේ පාට්නර් ඉන්නේ කෙළින්ම ඉස්සරහින්.</li><li>බෙදන කෙනාගේ දකුණු පැත්තේ ඉන්න කෙනාට මුලින්ම කාඩ් 4ක් ලැබෙනවා. ඒ 4 බලලා එයා <b>ට්‍රම්ප්</b> එක තෝරනවා. ඊට පස්සේ හැමෝටම තව කාඩ් 4ක්.</li><li>ට්‍රම්ප් තෝරපු කෙනා පළමු අත පටන් ගන්නවා. ගේම යන්නේ දකුණු පැත්තට (anticlockwise).</li><li>මුලින් දාපු පාට ඔයා ළඟ තියෙනවා නම් <b>ඒ පාටම දාන්න ඕනේ</b>. නැත්නම් ඕන කාඩ් එකක් දාන්න පුළුවන්, ට්‍රම්ප් එකකින් කපන්නත් පුළුවන්.</li><li>ලොකුම ට්‍රම්ප් එක, ට්‍රම්ප් නැත්නම් මුලින් දාපු පාටේ ලොකුම කාඩ් එක අත ගන්නවා. අත ගත්ත කෙනා ඊළඟ අත පටන් ගන්නවා.</li><li>අත් 8න් <b>5ක් හෝ වැඩිය</b> ගත්ත ටීම් එක වටය දිනනවා. ට්‍රම්ප් කිව්ව ටීම් එක නම් <b>ලකුණු 1</b>යි, අනිත් ටීම් එක නම් <b>ලකුණු 2</b>යි.</li><li>අත් 8ම ගත්තොත් <b>කපෝති</b>! ලකුණු කීයද කියලා සැකසුම් වලින් තෝරන්න.</li><li>4–4 සම වුණොත් කාටවත් ලකුණු නෑ. ඊළඟ වටය දිනන ටීම් එකට ලකුණක් අමතරව.</li><li>මුලින්ම ලකුණු <b>{t}</b>ට යන ටීම් එක ගේම දිනනවා. 🏆</li><li>බෙදන කෙනා හැම වටයකටම දකුණු පැත්තට මාරු වෙනවා.</li></ul>'
},
sl:{
  welcome:['Ayubowan! OMI gahanna lassthida? 😂','Card tika athata ganna, game patan gamu! 🃏','Ada kawda wadda? Balamuko! 😎','Trump eka hariyata thoraganoth game ape! 🔥','The ekak beela omi gahamu ☕'],
  play:'Game patan gamu', playSub:'Bots thundenek ekka ikman game ekak', random:'Ahambu aya ekka gahamu', private:'Private Room ekak', join:'Room ekakata yanna',
  leaderboard:'Lakunu', settings:'Settings', rules:'Neethi', profile:'Mage profile eka', nickname:'Nama', chooseAvatar:'Avatar eka thoranna',
  upload:'📷 Photo ekak danna', removePhoto:'Photo eka ain karanna', save:'Save karanna', namePh:'Oyage nama',
  language:'Bhashawa', comments:'Vihilu comments', sound:'Saddaya', voice:'Sinhala katahanda', voiceNote:'Oyage device eke Sinhala voice ekak thiyenawa nam vitharai.',
  speed:'Bots la ge wegaya', slow:'Hemin', normal:'Samanya', fast:'Wegen', target:'Dinanna ona lakunu', kapothiRule:'Kapothi (ath 8ma)', kap3:'Lakunu 3', kapGame:'Game ekama dinum', kapNone:'Samanya lakunu',
  kapNote:'Gamwala neethi wenas wenna puluwan — oyalage widihata thoranna.', timer:'Turn timer (thathpara 30)', on:'On', off:'Off', openRules:'📜 Neethi balanna',
  us:'Api', them:'Eyala', trump:'Trump', tricks:'Ath', you:'Oya',
  yourTurn:'Oyage waaraya! Card ekak danna', yourTurnTouch:'Oyage waaraya! Card eka ayeth tap karanna nathnam udata adinna', turnOf:'{n}ge waaraya...',
  chooseTrump:'Trump eka thoranna', chooseTrumpSub:'Oyage mul card 4 balala thoranna', choosingTrump:'{n} trump eka thoranawa... 🤔',
  trumpIs:'Trump eka {s}!', dealing:'Card bedanawa... 🃏', gameStart:'Onna game patan gannawa!', followSuit:'Ane bang, mulin dapu paatama danna one! 😅',
  roundUs:'Api watee dinuwa! 🎉', roundThem:'Eyala watee gaththa 😩', roundTie:'Ath 4yi 4yi, samai! 🤝', kapothiUs:'Kapothi! 🕊️ Ath 8ma ape!', kapothiThem:'Ammo, kapothi kaewa! 🕊️💀',
  whyCaller:'Trump kiwwa team eka dinuwa, e nisa lakunu 1yi.', whyDefender:'Trump nokiwwa team eka dinuwa, e nisa lakunu 2k!', whyKap:'Ath 8ma gaththa, kapothi!',
  whyTie:'Kaatawath lakunu nae. Eelanga watee dinana team ekata lakunu {c}k amatharawa!', carryAdd:'(sama wuna wateyen +{c})', nextRound:'Eelanga watee ▶',
  weWin:'Ape team eka dinum!', theyWin:'Eyala dinuwa... 😭', rematch:'Ayeth gahamuda? 🔁', home:'Mul pituwata 🏠', invite:'Yaaluwanta kiyanna 📨',
  inviteText:'Enna OMI LANKA gahamu! 🃏🇱🇰', copied:'Link eka copy wuna!',
  onlineTitle:'Online game 🌐', onlineBody:'Private rooms, room codes, invite links, random matchmaking walata real-time game server ekak one. Eka thamai eelanga piyawara (Phase 2). Danata Bots thundenek ekka supiri game ekak gahamu!', playBots:'Bots ekka gahamu 🤖',
  statsTitle:'Mage lakunu 🏆', statsNote:'Global leaderboard eka online accounts ekka enawa. Danata penne me device eke lakunu.',
  played:'Games', wins:'Dinum', losses:'Paradum', winPct:'Dinum %', streak:'Dan pela', best:'Hondama pela', kapothis:'Kapothi', awards:'Sammana', newAward:'Aluth sammanayak! {a}',
  quitTitle:'Game eka nawaththannada?', quitBody:'Me game eke lakunu nathi wenawa.', quitYes:'Ow, nawaththanna', quitNo:'Nae, digatama gahamu',
  tricksTaken:'Ath {n}', calledN:'Trump {n} wathawak', photoErr:'E photo eka ganna bari wuna. Wena ekak dala balanna.',
  suit:{S:'Ispeed',H:'Haart',D:'Diyamanthi',C:'Kalawar'},
  reacts:{'😢':'Dukai','😲':'Ammo!','😎':'Niyamai!','🏆':'Supiri wadak!','😂':'Hina yanawa','😡':'Kenthiyi!','❤️':'Aasai!','🤔':'Hithanawa...'},
  awardsList:{champ:['👑 OMI Champion','Games 10k dinanna'],unlucky:['😂 Awasanawe Raja','Games 5k paradinna'],comeback:['🔥 Comeback King','Lakunu 5k passen idala dinanna'],loser:['💀 Biggest Loser','Lakunakwath nathuwa paradinna'],master:['🎯 Card Master','Kapothiyak gahanna'],legend:['🃏 OMI Legend','Games 50k gahanna']},
  rulesTitle:'Omi neethi 📜',
  rulesBody:'<ul><li>Card <b>32</b>yi. Hama paatakinma 7 idan A dakwa. Lokuma <b>A</b>, eelangata K, Q, J, 10, 9, 8, podima <b>7</b>.</li><li>Sellam karanne hathara denai, team dekai. Oyage partner inne kelinma issarahin.</li><li>Bedana kenage dakunu paththe inna kenata mulinma card 4k labenawa. E 4 balala eya <b>trump</b> eka thoranawa. Eeta passe hamotama thawa card 4k.</li><li>Trump thorapu kena palamu atha patan gannawa. Game yanne dakunu paththata (anticlockwise).</li><li>Mulin dapu paata oya langa thiyenawa nam <b>e paatama danna one</b>. Nathnam ona card ekak danna puluwan, trump ekakin kapannath puluwan.</li><li>Lokuma trump eka, trump nathnam mulin dapu paate lokuma card eka atha gannawa. Atha gaththa kena eelanga atha patan gannawa.</li><li>Ath 8n <b>5k ho wadiya</b> gaththa team eka watee dinanawa. Trump kiwwa team eka nam <b>lakunu 1</b>yi, anith team eka nam <b>lakunu 2</b>yi.</li><li>Ath 8ma gaththoth <b>kapothi</b>! Lakunu keeyada kiyala settings walin thoranna.</li><li>4–4 sama wunoth kaatawath lakunu nae. Eelanga watee dinana team ekata lakunak amatharawa.</li><li>Mulinma lakunu <b>{t}</b>ta yana team eka game dinanawa. 🏆</li><li>Bedana kena hama wateekatama dakunu paththata maaru wenawa.</li></ul>'
},
en:{
  welcome:['Ayubowan! Ready to play some OMI? 😂','Grab your cards, let’s start! 🃏','Who’s the champ today? Let’s see! 😎','Pick the right trump and the game is ours! 🔥','Cup of tea and a round of Omi ☕'],
  play:'Play now', playSub:'Quick game with three bots', random:'Play with random players', private:'Private room', join:'Join room',
  leaderboard:'Stats', settings:'Settings', rules:'Rules', profile:'My profile', nickname:'Nickname', chooseAvatar:'Choose your avatar',
  upload:'📷 Upload a photo', removePhoto:'Remove photo', save:'Save', namePh:'Your nickname',
  language:'Language', comments:'Funny comments', sound:'Sound', voice:'Sinhala voice', voiceNote:'Works only if your device has a Sinhala voice installed.',
  speed:'Bot speed', slow:'Slow', normal:'Normal', fast:'Fast', target:'Points to win', kapothiRule:'Kapothi (all 8 tricks)', kap3:'3 points', kapGame:'Wins the game', kapNone:'Normal points',
  kapNote:'House rules vary from village to village, so pick yours.', timer:'Turn timer (30 seconds)', on:'On', off:'Off', openRules:'📜 Read the rules',
  us:'Us', them:'Them', trump:'Trump', tricks:'Tricks', you:'You',
  yourTurn:'Your turn! Play a card', yourTurnTouch:'Your turn! Tap the card again or swipe it up', turnOf:'{n}’s turn...',
  chooseTrump:'Choose trump', chooseTrumpSub:'Look at your first four cards and pick', choosingTrump:'{n} is choosing trump... 🤔',
  trumpIs:'Trump is {s}!', dealing:'Dealing cards... 🃏', gameStart:'Here we go, game on!', followSuit:'You have to follow the suit that was led! 😅',
  roundUs:'We won the round! 🎉', roundThem:'They took the round 😩', roundTie:'Four tricks each, it’s a tie! 🤝', kapothiUs:'Kapothi! 🕊️ All eight are ours!', kapothiThem:'Ouch, they got a kapothi! 🕊️💀',
  whyCaller:'The team that called trump won, so 1 point.', whyDefender:'The team that didn’t call trump won, so 2 points!', whyKap:'All eight tricks: kapothi!',
  whyTie:'No points this round. The next round’s winner gets {c} extra!', carryAdd:'(+{c} from the tied round)', nextRound:'Next round ▶',
  weWin:'Our team wins!', theyWin:'They won... 😭', rematch:'Play again? 🔁', home:'Home 🏠', invite:'Invite friends 📨',
  inviteText:'Come play OMI LANKA with me! 🃏🇱🇰', copied:'Link copied!',
  onlineTitle:'Online play 🌐', onlineBody:'Private rooms, room codes, invite links and random matchmaking need a real-time game server, which is the next phase of the build. For now, enjoy a full game with three bots!', playBots:'Play with bots 🤖',
  statsTitle:'My stats 🏆', statsNote:'The global leaderboard arrives with online accounts. For now these are your stats on this device.',
  played:'Played', wins:'Wins', losses:'Losses', winPct:'Win %', streak:'Streak', best:'Best streak', kapothis:'Kapothis', awards:'Awards', newAward:'New award! {a}',
  quitTitle:'Leave this game?', quitBody:'The score of this game will be lost.', quitYes:'Yes, leave', quitNo:'No, keep playing',
  tricksTaken:'{n} tricks', calledN:'Called trump {n}×', photoErr:'Couldn’t use that photo. Try another one.',
  suit:{S:'Spades',H:'Hearts',D:'Diamonds',C:'Clubs'},
  reacts:{'😢':'Sad','😲':'Wow!','😎':'Nice!','🏆':'Good job!','😂':'LOL','😡':'Angry','❤️':'Love it!','🤔':'Thinking'},
  awardsList:{champ:['👑 OMI Champion','Win 10 games'],unlucky:['😂 King of Bad Luck','Lose 5 games'],comeback:['🔥 Comeback King','Win after trailing by 5'],loser:['💀 Biggest Loser','Lose without scoring a point'],master:['🎯 Card Master','Win a kapothi'],legend:['🃏 OMI Legend','Play 50 games']},
  rulesTitle:'How to play Omi 📜',
  rulesBody:'<ul><li>32 cards: 7 to Ace in each suit. <b>Ace</b> is highest, then K, Q, J, 10, 9, 8, and <b>7</b> is lowest.</li><li>Four players in two teams. Your partner sits directly opposite you.</li><li>The player to the dealer’s right gets four cards first, looks at them and chooses <b>trump</b>. Then everyone gets four more.</li><li>The trump caller leads the first trick. Play moves to the right (anticlockwise).</li><li>If you have the suit that was led, <b>you must follow it</b>. If not, play anything, including a trump to cut.</li><li>The highest trump wins the trick, or the highest card of the led suit if no trump was played. The winner leads next.</li><li>The team that takes <b>5 or more</b> of the 8 tricks wins the round: <b>1 point</b> if they called trump, <b>2 points</b> if the other team called it.</li><li>Taking all 8 tricks is a <b>kapothi</b>! Choose its value in Settings.</li><li>A 4–4 tie scores nothing; the next round’s winner gets an extra point.</li><li>First team to <b>{t}</b> points wins the game. 🏆</li><li>The deal passes to the right each round.</li></ul>'
}};
function t(k,v){let s=T[S.lang]&&T[S.lang][k];if(s===undefined)s=T.en[k];if(typeof s==='string'&&v)s=s.replace(/\{(\w+)\}/g,(m,a)=>v[a]!==undefined?v[a]:m);return s}

/* funny comments [si, singlish, en] */
const C={
  start:[['ගේම පටන් ගමු! 💪','Game patan gamu! 💪','Let’s go! 💪'],['අද නම් අපි දිනනවා!','Ada nam api dinanawa!','We’re winning today!'],['කාඩ් හොඳට බෙදපන් හොඳේ 😂','Card hondata bedapan honde 😂','Deal me good cards, okay? 😂']],
  goodHand:[['අද නම් ගොඩ!','Ada nam goda!','Today’s a jackpot!'],['අම්මෝ! සුපිරි කාඩ් ටිකක්!','Ammo! Supiri card tikak!','Wow, what a hand!'],['අද මගේ දවස!','Ada mage dawasa!','Today is my day!'],['ගේම මගේ අතේ!','Game mage athe!','The game is in my hands!']],
  badMove:[['මොකක්ද බං ඒ දැම්මේ? 😂','Mokakda bang e damme? 😂','What did you just play, machan? 😂'],['කාඩ් ගහන්න දන්නෙ නැද්ද?','Card gahanna danne naddha?','Do you even know how to play?'],['අනේ අම්මෝ!','Ane ammo!','Oh my goodness!'],['ඒක නම් හිතාගන්න බෑ!','Eka nam hithaganna bae!','Never saw that coming!'],['පාට්නර්ගේ අතත් කපනවද? 🤦','Partnerge athath kapanawada? 🤦','Cutting your own partner? 🤦']],
  trickWin:[['අන්න වැඩ්ඩා!','Anna wadda!','That’s a master!'],['කොහොමද ඒක?','Kohomada eka?','How about that?'],['සුපිරි ගැහිල්ලක්!','Supiri gahillak!','Super shot!'],['දැන් තමයි ගේම!','Dan thamai game!','Now it’s a game!']],
  aceLost:[['A එකත් ගියා! අනේ අපොයි 😭','A ekath giya! Ane apoi 😭','Even the Ace is gone! 😭'],['ආස් එකක් කෑවා! 😂','Ace ekak kaewa! 😂','Somebody ate an Ace! 😂']],
  roundWin:[['ලකුණු ටික එනවා! 🔥','Lakunu tika enawa! 🔥','Points rolling in! 🔥'],['දැන් තමයි ගේම!','Dan thamai game!','Now it’s a game!'],['අපිව නවත්තන්න බෑ!','Apiwa nawaththanna bae!','Nobody can stop us!']],
  lose:[['අද නම් අපි ඉවරයි!','Ada nam api iwarai!','We’re done for today!'],['වාසනාව නැති දවසක්!','Waasanawa nathi dawasak!','Just not our lucky day!'],['ඊළඟ ගේමේ බලමු!','Eelanga game eke balamu!','We’ll see next game!'],['කාඩ් ටිකත් අපිට විරුද්ධයි!','Card tikath apita viruddhai!','Even the cards are against us!']],
  gameWin:[['කවුද දැන් වැඩ්ඩෝ?','Kawda dan waddo?','Who’s the boss now?'],['අන්න ඒකයි ගේම!','Anna ekai game!','Now THAT’s a game!'],['ජයග්‍රහණය අපේ!','Jayagrahanaya ape!','Victory is ours!'],['අද රෑ අපේ රෑ!','Ada rae ape rae!','Tonight is our night!']],
  kapothi:[['කපෝති! 🕊️ කවුද දැන් වැඩ්ඩෝ?','Kapothi! 🕊️ Kawda dan waddo?','Kapothi! 🕊️ Who’s the boss now?'],['අත් අටම අපේ! 😎','Ath atama ape! 😎','All eight tricks are ours! 😎']]
};

/* ================= AVATARS ================= */
const AVBG={uncle:'#ffd23f',champ:'#12b886',sleepy:'#3b5bb5',angry:'#ff5a5f',cool:'#ff8c42',village:'#8ce0b9',cat:'#ffe08a',elephant:'#9ad0ff'};
const N='#0b1a3a';
const AV={
uncle:`<ellipse cx="20" cy="58" rx="6" ry="8" fill="#a8652f"/><ellipse cx="80" cy="58" rx="6" ry="8" fill="#a8652f"/><circle cx="50" cy="56" r="30" fill="#c68642"/><ellipse cx="44" cy="34" rx="10" ry="4" fill="#fff" opacity=".35"/><path d="M22 52 Q22 38 32 34" stroke="#eee" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M78 52 Q78 38 68 34" stroke="#eee" stroke-width="7" fill="none" stroke-linecap="round"/><circle cx="40" cy="53" r="8" fill="#fff" stroke="${N}" stroke-width="2.5"/><circle cx="60" cy="53" r="8" fill="#fff" stroke="${N}" stroke-width="2.5"/><line x1="48" y1="53" x2="52" y2="53" stroke="${N}" stroke-width="2.5"/><circle cx="41" cy="54" r="2.8" fill="${N}"/><circle cx="61" cy="54" r="2.8" fill="${N}"/><path d="M32 68 Q41 61 50 66 Q59 61 68 68 Q59 72 50 69 Q41 72 32 68Z" fill="#eee"/><path d="M42 76 Q50 81 58 76" stroke="#7a2e1f" stroke-width="3" fill="none" stroke-linecap="round"/>`,
champ:`<circle cx="50" cy="58" r="29" fill="#8d5524"/><path d="M28 36 L32 14 L41 27 L50 9 L59 27 L68 14 L72 36 Z" fill="#ffd23f" stroke="#c99700" stroke-width="2.5" stroke-linejoin="round"/><circle cx="50" cy="24" r="3" fill="#ff5a5f"/><path d="M36 54 Q41 48 46 54" stroke="${N}" stroke-width="3.5" fill="none" stroke-linecap="round"/><path d="M54 54 Q59 48 64 54" stroke="${N}" stroke-width="3.5" fill="none" stroke-linecap="round"/><path d="M36 64 Q50 82 64 64 Z" fill="#fff" stroke="${N}" stroke-width="2.5" stroke-linejoin="round"/><circle cx="31" cy="64" r="4" fill="#ff8c8c" opacity=".6"/><circle cx="69" cy="64" r="4" fill="#ff8c8c" opacity=".6"/>`,
sleepy:`<circle cx="50" cy="58" r="29" fill="#e0ac69"/><path d="M22 42 Q38 8 76 36 Z" fill="#ff5a5f"/><path d="M22 42 Q50 32 76 36" stroke="#fff" stroke-width="5" fill="none"/><circle cx="80" cy="38" r="6" fill="#fff"/><path d="M35 56 Q40 61 45 56" stroke="${N}" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M55 56 Q60 61 65 56" stroke="${N}" stroke-width="3" fill="none" stroke-linecap="round"/><ellipse cx="50" cy="72" rx="5" ry="6" fill="#7a2e1f"/><text x="70" y="26" font-size="14" font-weight="800" fill="#fff" font-family="sans-serif">z</text><text x="80" y="16" font-size="10" font-weight="800" fill="#fff" font-family="sans-serif">z</text>`,
angry:`<circle cx="18" cy="26" r="6" fill="#fff" opacity=".85"/><circle cx="12" cy="18" r="4" fill="#fff" opacity=".7"/><circle cx="82" cy="26" r="6" fill="#fff" opacity=".85"/><circle cx="88" cy="18" r="4" fill="#fff" opacity=".7"/><circle cx="50" cy="56" r="30" fill="#d9774b"/><path d="M30 28 Q50 18 70 28 Q60 26 50 30 Q40 26 30 28Z" fill="#2b1a10"/><path d="M33 45 L46 51" stroke="${N}" stroke-width="5" stroke-linecap="round"/><path d="M67 45 L54 51" stroke="${N}" stroke-width="5" stroke-linecap="round"/><circle cx="41" cy="57" r="3.5" fill="${N}"/><circle cx="59" cy="57" r="3.5" fill="${N}"/><path d="M38 75 Q50 66 62 75" stroke="${N}" stroke-width="3.5" fill="none" stroke-linecap="round"/>`,
cool:`<circle cx="50" cy="58" r="29" fill="#a0522d"/><path d="M24 46 Q22 20 50 18 Q72 16 78 34 Q66 26 52 30 Q38 26 24 46Z" fill="#1a1a1a"/><rect x="28" y="47" width="20" height="12" rx="5" fill="${N}"/><rect x="52" y="47" width="20" height="12" rx="5" fill="${N}"/><line x1="47" y1="51" x2="53" y2="51" stroke="${N}" stroke-width="3"/><path d="M32 50 L38 50" stroke="#fff" stroke-width="2" opacity=".7"/><path d="M56 50 L62 50" stroke="#fff" stroke-width="2" opacity=".7"/><path d="M40 72 Q52 77 61 68" stroke="#3b1a0f" stroke-width="3.5" fill="none" stroke-linecap="round"/>`,
village:`<circle cx="50" cy="60" r="28" fill="#b5794a"/><ellipse cx="50" cy="38" rx="40" ry="9" fill="#e9c46a" stroke="#b8902e" stroke-width="2"/><path d="M32 38 Q34 16 50 16 Q66 16 68 38Z" fill="#f4d58d" stroke="#b8902e" stroke-width="2"/><rect x="32" y="31" width="36" height="6" fill="#ff5a5f"/><circle cx="41" cy="56" r="3.2" fill="${N}"/><circle cx="59" cy="56" r="3.2" fill="${N}"/><path d="M36 66 Q50 82 64 66 Z" fill="#fff" stroke="${N}" stroke-width="2.5" stroke-linejoin="round"/><rect x="48" y="66" width="4" height="5" fill="${N}"/><g fill="#5a3a20" opacity=".55"><circle cx="34" cy="74" r="1.2"/><circle cx="38" cy="79" r="1.2"/><circle cx="62" cy="79" r="1.2"/><circle cx="66" cy="74" r="1.2"/><circle cx="50" cy="84" r="1.2"/></g>`,
cat:`<path d="M22 44 L26 14 L44 32Z" fill="#ff9f43"/><path d="M78 44 L74 14 L56 32Z" fill="#ff9f43"/><path d="M27 36 L28 21 L37 31Z" fill="#ffc7d1"/><path d="M73 36 L72 21 L63 31Z" fill="#ffc7d1"/><circle cx="50" cy="56" r="30" fill="#ff9f43"/><path d="M50 30 L46 40 M50 30 L54 40 M42 31 L42 40 M58 31 L58 40" stroke="#e07b1a" stroke-width="3" stroke-linecap="round"/><ellipse cx="39" cy="54" rx="6" ry="7" fill="#7ee081"/><ellipse cx="61" cy="54" rx="6" ry="7" fill="#7ee081"/><ellipse cx="39" cy="54" rx="2" ry="6" fill="${N}"/><ellipse cx="61" cy="54" rx="2" ry="6" fill="${N}"/><path d="M46 64 L54 64 L50 68Z" fill="#ff6b8a"/><path d="M42 72 Q46 76 50 70 Q54 76 58 72" stroke="${N}" stroke-width="2.5" fill="none" stroke-linecap="round"/><path d="M14 62 L32 66 M14 70 L32 70 M86 62 L68 66 M86 70 L68 70" stroke="#fff" stroke-width="2" stroke-linecap="round"/>`,
elephant:`<ellipse cx="20" cy="54" rx="17" ry="22" fill="#8a95a3"/><ellipse cx="80" cy="54" rx="17" ry="22" fill="#8a95a3"/><ellipse cx="22" cy="55" rx="10" ry="14" fill="#f2a7b5"/><ellipse cx="78" cy="55" rx="10" ry="14" fill="#f2a7b5"/><circle cx="50" cy="50" r="26" fill="#a3aebb"/><path d="M33 30 Q50 22 67 30 L62 44 Q50 48 38 44Z" fill="#ff5a5f" stroke="#ffd23f" stroke-width="2"/><g fill="#ffd23f"><circle cx="44" cy="36" r="2"/><circle cx="50" cy="38" r="2"/><circle cx="56" cy="36" r="2"/></g><circle cx="41" cy="52" r="3.2" fill="${N}"/><circle cx="59" cy="52" r="3.2" fill="${N}"/><path d="M46 60 Q44 76 50 86 Q56 92 60 84" stroke="#a3aebb" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M38 64 L34 72 M62 64 L66 72" stroke="#fff" stroke-width="4" stroke-linecap="round"/>`
};
const CHARIDS=Object.keys(OmiChars.CHARS);for(const id of CHARIDS){AV[id]=OmiChars.charInner(id,'neutral');AVBG[id]=OmiChars.CHARS[id].bg}
const AVLIST=()=>[...CHARIDS,...Object.keys(AV).filter(k=>!CHARIDS.includes(k))];
const EMO_KEY={};for(const k in OmiChars.EMOJI)EMO_KEY[OmiChars.EMOJI[k]]=k;
function emoteFace(av,emo){const k=EMO_KEY[emo];return OmiChars.CHARS[av]&&k?OmiChars.charSVG(av,k):`<span>${emo}</span>`}
function avatarSVG(id){return `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">${AV[id]||AV.cool}</svg>`}
function avatarHTML(id,photo){return photo?`<img src="${photo}" alt="">`:avatarSVG(id)}
const BOTS=[
  {avatar:'uncle',names:['සුනිල් මාමා','Sunil Mama','Uncle Sunil']},
  {avatar:'sleepy',names:['නිදිමත නිමල්','Nidimatha Nimal','Sleepy Nimal']},
  {avatar:'champ',names:['චැම්පියන් චමින්ද','Champion Chaminda','Champion Chaminda']},
  {avatar:'angry',names:['කේන්ති කමල්','Kenthi Kamal','Grumpy Kamal']},
  {avatar:'village',names:['ගමේ ගුණේ','Game Gune','Village Gune']},
  {avatar:'cat',names:['පූසා පුංචි','Poosa Punchi','Punchi the Cat']},
  {avatar:'elephant',names:['අලියා අජිත්','Aliya Ajith','Ajith the Elephant']},
  {avatar:'cool',names:['කූල් චතුර','Cool Chathura','Cool Chathura']},
  {avatar:'kasun',names:['කසුන්','Kasun','Kasun']},
  {avatar:'dilini',names:['දිලිනි','Dilini','Dilini']},
  {avatar:'nuwan',names:['නුවන්','Nuwan','Nuwan']},
  {avatar:'sachini',names:['සචිනි','Sachini','Sachini']}
];

/* ================= SOUND & VOICE ================= */
let AC=null;
function actx(){if(!AC){try{AC=new (window.AudioContext||window.webkitAudioContext)()}catch(e){return null}}if(AC.state==='suspended')AC.resume();return AC}
function tone(f,dur,o={}){const a=actx();if(!a)return;const {type='sine',vol=.12,at=0,slide=0}=o;const t0=a.currentTime+at;const osc=a.createOscillator(),g=a.createGain();osc.type=type;osc.frequency.setValueAtTime(f,t0);if(slide)osc.frequency.exponentialRampToValueAtTime(Math.max(40,f*slide),t0+dur);g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(vol,t0+.01);g.gain.exponentialRampToValueAtTime(.0001,t0+dur);osc.connect(g).connect(a.destination);osc.start(t0);osc.stop(t0+dur+.03)}
function noise(dur,o={}){const a=actx();if(!a)return;const {vol=.3,freq=2500}=o;const n=Math.floor(a.sampleRate*dur);const b=a.createBuffer(1,n,a.sampleRate);const d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,2);const s=a.createBufferSource();s.buffer=b;const f=a.createBiquadFilter();f.type='bandpass';f.frequency.value=freq;f.Q.value=.8;const g=a.createGain();g.gain.value=vol;s.connect(f).connect(g).connect(a.destination);s.start()}
function sfx(n){if(!S.sound)return;try{switch(n){
  case'card':noise(.09,{vol:.6,freq:1800});tone(170,.08,{type:'triangle',vol:.07});break;
  case'deal':noise(.05,{vol:.25,freq:3200});break;
  case'click':tone(660,.07,{type:'triangle',vol:.08});break;
  case'pop':tone(520,.14,{vol:.1,slide:1.8});break;
  case'err':tone(210,.18,{type:'square',vol:.04,slide:.7});break;
  case'trick':tone(784,.12,{type:'triangle',vol:.1});tone(1047,.2,{type:'triangle',vol:.1,at:.09});break;
  case'trump':[523,659,784,1047].forEach((f,i)=>tone(f,.25,{type:'triangle',vol:.09,at:i*.07}));break;
  case'round':[659,784,988].forEach((f,i)=>tone(f,.3,{vol:.1,at:i*.1}));break;
  case'win':[523,659,784,1047,784,1047].forEach((f,i)=>tone(f,.35,{type:'triangle',vol:.12,at:i*.12}));break;
  case'lose':[392,370,349,330].forEach((f,i)=>tone(f,.42,{type:'sawtooth',vol:.04,at:i*.28,slide:.97}));break;
}}catch(e){}}
function speak(txt){
  if(!S.voice||!('speechSynthesis' in window))return;
  try{const vs=speechSynthesis.getVoices();const si=vs.find(v=>/^si/i.test(v.lang));
    if(S.lang==='si'&&!si)return;
    const u=new SpeechSynthesisUtterance(txt.replace(/[^\p{L}\p{M}\p{N}\s!?.,]/gu,'').trim());
    if(S.lang==='si'){u.voice=si;u.lang=si.lang}else u.lang='en-US';
    speechSynthesis.cancel();speechSynthesis.speak(u)}catch(e){}
}

/* ================= EXTRA TEXT (online) ================= */
Object.assign(T.si,{roomCode:'Room code', codeCopied:'Code එක කොපි වුණා! යාළුවන්ට යවන්න 📨', lobbyNote:'යාළුවන්ට මේ room code එක දෙන්න. එයාලට මේ artifact එක share කරලා තියෙන්න ඕනේ (Share → invite).', emptySeat:'හිස් තැන', tapSit:'tap කරලා වාඩි වෙන්න', botTag:'Bot', hostTag:'Host', youTag:'ඔයා', startGame:'ගේම පටන් ගමු ▶', startBots:'Bots දාලා පටන් ගමු ▶', waitingHost:'Host ගේම පටන් ගන්නකම් ඉන්න... ⏳', enterCode:'යාළුවා දුන්න අකුරු 5ක room code එක ගහන්න', joinGo:'යමු ▶', noRoom:'ඒ room එක හොයාගන්න බෑ. Code එක හරිද බලන්න.', roomErr:'Room එකට සම්බන්ධ වෙන්න බැරි වුණා. ආයෙත් උත්සාහ කරන්න.', hostLeft:'Host ගියා 😢 මේ ගේම නැවතුනා.', onlineNA:'Online ගේම් වැඩ කරන්නේ claude.ai එකට sign in වෙලා මේ artifact එක open කළාම විතරයි. දැනට Bots එක්ක ගහමු!', searching:'Players හොයනවා... 🔍', autoStart:'තත්පර {s}කින් පටන් ගන්නවා, හිස් තැන් වලට Bots', connecting:'Room එකට සම්බන්ධ වෙනවා...', spect:'ඔයා බලාගෙන ඉන්නවා 👀', rematchWait:'Host ආයෙත් පටන් ගන්නකම් ඉන්න... ⏳', publicTbl:'Public table 🎲', privateTbl:'Private room 🔒', leaveTitle:'Room එකෙන් යන්නද?', leaveBody:'ඔයා host නම් හැමෝටම ගේම නවතිනවා.', inviteCode:'OMI LANKA ගහමු! 🃏 Room code: {c}'});
Object.assign(T.sl,{roomCode:'Room code', codeCopied:'Code eka copy wuna! Yaaluwanta yawanna 📨', lobbyNote:'Yaaluwanta me room code eka denna. Eyalata me artifact eka share karala thiyenna one (Share → invite).', emptySeat:'His thana', tapSit:'tap karala wadi wenna', botTag:'Bot', hostTag:'Host', youTag:'Oya', startGame:'Game patan gamu ▶', startBots:'Bots dala patan gamu ▶', waitingHost:'Host game patan gannakam inna... ⏳', enterCode:'Yaaluwa dunna akuru 5ka room code eka gahanna', joinGo:'Yamu ▶', noRoom:'E room eka hoyaganna bae. Code eka harida balanna.', roomErr:'Room ekata sambandha wenna bari wuna. Ayeth try karanna.', hostLeft:'Host giya 😢 Me game eka nawathuna.', onlineNA:'Online game wada karanne claude.ai ekata sign in wela me artifact eka open kalama vitharai. Danata Bots ekka gahamu!', searching:'Players hoyanawa... 🔍', autoStart:'Thathpara {s}kin patan gannawa, his than walata Bots', connecting:'Room ekata sambandha wenawa...', spect:'Oya balagena innawa 👀', rematchWait:'Host ayeth patan gannakam inna... ⏳', publicTbl:'Public table 🎲', privateTbl:'Private room 🔒', leaveTitle:'Room eken yannada?', leaveBody:'Oya host nam hamotama game eka nawathinawa.', inviteCode:'OMI LANKA gahamu! 🃏 Room code: {c}'});
Object.assign(T.en,{roomCode:'Room code', codeCopied:'Code copied! Send it to your friends 📨', lobbyNote:'Give your friends this room code. They need access to this artifact (Share → invite).', emptySeat:'Empty seat', tapSit:'Tap to sit here', botTag:'Bot', hostTag:'Host', youTag:'You', startGame:'Start the game ▶', startBots:'Fill with bots and start ▶', waitingHost:'Waiting for the host to start... ⏳', enterCode:'Type the 5-letter room code your friend gave you', joinGo:'Join ▶', noRoom:'Couldn’t find that room. Check the code and try again.', roomErr:'Couldn’t connect to the room. Try again.', hostLeft:'The host left 😢 This game has ended.', onlineNA:'Online play works when you’re signed in to claude.ai and open this artifact there. For now, let’s play with bots!', searching:'Looking for players... 🔍', autoStart:'Starting in {s}s, bots fill empty seats', connecting:'Connecting to the room...', spect:'You’re watching 👀', rematchWait:'Waiting for the host to start again... ⏳', publicTbl:'Public table 🎲', privateTbl:'Private room 🔒', leaveTitle:'Leave the room?', leaveBody:'If you’re the host, the game ends for everyone.', inviteCode:'Let’s play OMI LANKA! 🃏 Room code: {c}'});

/* ================= UI HELPERS ================= */

const PIPS={'7':[[0,0],[2,0],[1,.25],[0,.5],[2,.5],[0,1],[2,1]],'8':[[0,0],[2,0],[1,.25],[0,.5],[2,.5],[1,.75],[0,1],[2,1]],'9':[[0,0],[2,0],[0,1/3],[2,1/3],[1,.5],[0,2/3],[2,2/3],[0,1],[2,1]],'10':[[0,0],[2,0],[1,1/6],[0,1/3],[2,1/3],[0,2/3],[2,2/3],[1,5/6],[0,1],[2,1]]};
const COURT={K:1,Q:1,J:1};const courtCache={};
function courtSVG(r,s){
  const k=r+s;if(courtCache[k])return courtCache[k];
  const ink='#1a1a1a',R='#d22630',B='#2350a6',Y='#f3c02f',SK='#fde3bf',sc=RED[s]?R:ink,sym=SYM[s];
  const L=`stroke="${ink}" stroke-width=".55" stroke-linejoin="round"`;
  let hair='',head='',prop='',robe2='';
  if(r==='K'){
    hair=`<path d="M23.5 15 Q22 22 25 25 L35 25 Q38 22 36.5 15" fill="${Y}" ${L}/><path d="M25.5 22 Q30 31 34.5 22 Q32 25.5 30 25.5 Q28 25.5 25.5 22Z" fill="${Y}" ${L}/><path d="M27 21.6 Q30 20.4 33 21.6" fill="none" stroke="${ink}" stroke-width=".6"/>`;
    head=`<path d="M22.5 11 L23.5 4 L26.5 8 L30 2.5 L33.5 8 L36.5 4 L37.5 11 Z" fill="${Y}" ${L}/><rect x="22.5" y="10" width="15" height="2.6" fill="${R}" ${L}/><circle cx="30" cy="6.5" r="1.1" fill="${B}"/>`;
    prop=`<path d="M44 4 L46 4 L46 30 L44 30 Z" fill="#cfd6df" ${L}/><path d="M41 28 L49 28 L49 30 L41 30 Z" fill="${Y}" ${L}/>`;
  }else if(r==='Q'){
    hair=`<path d="M23 13 Q20 26 24 31 L27 25 Q24 19 25 14Z M37 13 Q40 26 36 31 L33 25 Q36 19 35 14Z" fill="${Y}" ${L}/>`;
    head=`<path d="M24 12 L25 6 L27.5 9 L30 5 L32.5 9 L35 6 L36 12 Z" fill="${Y}" ${L}/><rect x="24" y="11" width="12" height="2.2" fill="${B}" ${L}/><circle cx="30" cy="7.5" r=".9" fill="${R}"/>`;
    prop=`<path d="M13 22 L16 33" stroke="#2f7d32" stroke-width="1"/><circle cx="12.5" cy="20.5" r="2.3" fill="${R}" ${L}/><circle cx="12.5" cy="20.5" r=".8" fill="${Y}"/>`;
  }else{
    hair=`<path d="M23.5 14 Q22.5 22 25 24 L25.5 16 Z M36.5 14 Q37.5 22 35 24 L34.5 16Z" fill="#8a5a2b" ${L}/><path d="M28 23 Q30 24.2 32 23" fill="none" stroke="${ink}" stroke-width=".6"/>`;
    head=`<path d="M22 13 Q30 5 38 13 Z" fill="${R}" ${L}/><rect x="22" y="12" width="16" height="2" fill="${Y}" ${L}/><path d="M36 9 Q44 2 47 6 Q42 6 37.5 11Z" fill="${B}" ${L}/>`;
    prop=`<path d="M46 8 Q50 18 46 30 Q43 18 46 8Z" fill="${Y}" ${L}/><line x1="46" y1="10" x2="46" y2="30" stroke="${ink}" stroke-width=".5"/>`;
  }
  const face=`<ellipse cx="30" cy="18.5" rx="5.6" ry="6.6" fill="${SK}" ${L}/><path d="M26.6 17.2 h1.8 M31.6 17.2 h1.8" stroke="${ink}" stroke-width=".7"/><path d="M30 17.6 L29.2 20.6 L30.4 20.6" fill="none" stroke="${ink}" stroke-width=".45"/>`;
  const robe=`<path d="M5 45 L5 34 Q8 27 18 26 L42 26 Q52 27 55 34 L55 45 Z" fill="${R}" ${L}/>
   <path d="M22 26 L30 45 L38 26 Z" fill="${Y}" ${L}/><path d="M25 26 L30 37 L35 26" fill="none" stroke="${ink}" stroke-width=".5"/>
   <path d="M5 37 Q9 31 17 30 L19 45 L5 45 Z" fill="${B}" ${L}/><path d="M55 37 Q51 31 43 30 L41 45 L55 45 Z" fill="${B}" ${L}/>
   <path d="M6 41 l2 -2 l2 2 l2 -2 l2 2 l2 -2 l2 2 M42 41 l2 -2 l2 2 l2 -2 l2 2 l2 -2 l2 2" fill="none" stroke="${Y}" stroke-width=".9"/>
   <path d="M18 26 Q30 30 42 26" fill="none" stroke="${ink}" stroke-width=".55"/>`;
  const half=`<g>${prop}${robe}${hair}${face}${head}<text x="9" y="13" font-size="9" fill="${sc}" font-family="Georgia,serif">${sym}</text></g>`;
  const id='cc'+k.replace(/\W/g,'');
  return courtCache[k]=`<svg viewBox="0 0 60 110" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><defs><clipPath id="${id}"><rect x="1" y="1" width="58" height="54"/></clipPath></defs><rect x="1" y="1" width="58" height="108" fill="#fff"/><g clip-path="url(#${id})"><g transform="scale(1 1.222)">${half}</g></g><g transform="rotate(180 30 55)"><g clip-path="url(#${id})"><g transform="scale(1 1.222)">${half}</g></g></g><line x1="1" y1="55" x2="59" y2="55" stroke="${ink}" stroke-width=".7"/><rect x="1" y="1" width="58" height="108" fill="none" stroke="${sc}" stroke-width="1.1"/></svg>`;
}
function cardEl(c){
  const d=document.createElement('div');d.className='card '+(RED[c.s]?'red':'black');
  const sym=SYM[c.s];
  const mid=COURT[c.r]?`<div class="court">${courtSVG(c.r,c.s)}</div>`:c.r==='A'?`<div class="ace">${sym}</div>`:`<div class="pips">${(PIPS[c.r]||[]).map(([x,y])=>`<i class="${y>.5?'f':''}" style="left:${x*50}%;top:${y*100}%">${sym}</i>`).join('')}</div>`;
  d.innerHTML=`<div class="ix"><span>${c.r}</span><span>${sym}</span></div>${mid}<div class="ix b"><span>${c.r}</span><span>${sym}</span></div>`;
  d.setAttribute('aria-label',c.r+' '+t('suit')[c.s]);return d;
}
const CARDIDS=new Set(Omi.deck().map(c=>c.id));
function cardFromId(id){if(typeof id!=='string'||!CARDIDS.has(id))return null;return{r:id.slice(0,-1),s:id.slice(-1),id}}
function toast(msg){const e=$('#toast');e.textContent=msg;e.classList.add('show');clearTimeout(e._t);e._t=setTimeout(()=>e.classList.remove('show'),2600)}
function showScreen(id){$$('.screen').forEach(s=>s.classList.toggle('active',s.id===id))}
const SPD=()=>({slow:1.5,normal:1,fast:.55}[S.speed]||1);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function relRect(el){const tr=$('#table').getBoundingClientRect(),r=el.getBoundingClientRect();return{x:r.left-tr.left,y:r.top-tr.top,w:r.width,h:r.height}}
function pick(a){return a[rand(a.length)]}
const touchUI=()=>matchMedia('(pointer: coarse)').matches;
const REPLY={'😢':'❤️','😲':'😎','😎':'🏆','🏆':'😎','😂':'😂','😡':'😂','❤️':'❤️','🤔':'😎'};

/* ================= IDENTITY ================= */
let CID=null;try{CID=localStorage.getItem('omilanka:cid')}catch(e){}
if(!CID||!/^[a-z0-9]{8,40}$/i.test(CID)){CID=Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>'abcdefghijkmnpqrstuvwxyz23456789'[b%32]).join('');try{localStorage.setItem('omilanka:cid',CID)}catch(e){}}
const cleanName=n=>String(n||'').replace(/[\u0000-\u001f\u007f\u200b\u200e\u200f\u202a-\u202e\u2060-\u2064\ufeff]/g,'').trim().slice(0,16);
/* ================= BOT AI ================= */
const Bot={
  chooseTrump(h){let best=h[0].s,bs=-1;for(const s of SUITS){const cs=h.filter(c=>c.s===s);if(!cs.length)continue;const sc=cs.length*10+cs.reduce((a,c)=>a+Omi.v(c),0)+rand(3);if(sc>bs){bs=sc;best=s}}return best},
  play(h,tr,T,seat){
    const legal=Omi.legal(h,tr),cost=c=>(c.s===T?20:0)+Omi.v(c);
    const low=a=>a.slice().sort((x,y)=>cost(x)-cost(y))[0],high=a=>a.slice().sort((x,y)=>cost(y)-cost(x))[0];
    if(!tr.length){
      const nonT=legal.filter(c=>c.s!==T),trumps=legal.filter(c=>c.s===T);
      const aces=nonT.filter(c=>c.r==='A');if(aces.length)return aces[0];
      if(trumps.length>=3&&trumps.some(c=>c.r==='A'||c.r==='K'))return high(trumps);
      if(nonT.length){const by={};nonT.forEach(c=>(by[c.s]=by[c.s]||[]).push(c));return low(Object.values(by).sort((a,b)=>b.length-a.length)[0])}
      return low(legal);
    }
    const wi=Omi.winnerIdx(tr,T),wc=tr[wi].card,led=tr[0].card.s;
    if(tr[wi].seat%2===seat%2)return low(legal);
    const winners=legal.filter(c=>Omi.beats(c,wc,T));
    if(winners.length){if(tr.length===3)return low(winners);const top=winners.filter(c=>c.s===led&&c.r==='A');return top.length?top[0]:low(winners)}
    return low(legal);
  }
};

/* ================= HOST ENGINE (authoritative game server) ================= */
function makeHost(o){
  const H={gen:0,ids:['me',null,null,null],pk:[null,null,null,null],lastSeq:[0,0,0,0],lastRx:[],offAt:[0,0,0,0],pending:null,contRes:null,contRej:null,lastSay:0,lastIdx:{},enc:[],hands:[[],[],[],[]],trick:[],pubTbl:!!o.pubTbl,lobbyEnd:o.pubTbl?Date.now()+25000:0,rbN:0,endN:0};
  const s=H.s={v:0,ph:o.lobby?'lobby':'start',seats:o.seats,sc:[0,0],cr:0,tg:S.target,kp:S.kapothi,dl:0,cl:null,tp:null,tu:null,tk:[],tr:[0,0],nc:[0,0,0,0],pt:[0,0,0,0],calls:[0,0,0,0],rn:0,cx:[0,-1],ev:[0],rb:null,end:null,tl:0,as:0};
  H.view=()=>JSON.parse(JSON.stringify(s));
  H.pub=()=>{s.v++;o.onPub(H)};
  H.isBot=i=>!!(s.seats[i]&&s.seats[i].b!==undefined);
  H.wait=async ms=>{const g=H.gen;await sleep(ms*SPD());if(g!==H.gen)throw'cancel'};
  H.later=(fn,ms)=>{const g=H.gen;setTimeout(()=>{if(g===H.gen){fn();H.pub()}},ms)};
  const bots=f=>[0,1,2,3].filter(i=>H.isBot(i)&&(!f||f(i)));
  H.speaker=f=>{const b=bots(f);return b.length?pick(b):-1};
  H.say=(seat,key,force)=>{const now=Date.now();if(!force&&now-H.lastSay<1800)return;H.lastSay=now;const arr=C[key];let i=rand(arr.length);if(arr.length>1&&i===H.lastIdx[key])i=(i+1)%arr.length;H.lastIdx[key]=i;s.ev=[s.ev[0]+1,seat,key,i]};
  H.rx=(seat,e)=>{if(seat>=0)s.ev=[s.ev[0]+1,seat,'@',e]};
  H.humanRx=(seat,e)=>{if(!REPLY[e]||Math.random()>=.45)return;const b=H.speaker(i=>i!==seat);if(b>=0)H.later(()=>H.rx(b,REPLY[e]),900+rand(600))};
  H.input=(seat,kind,val)=>{
    const p=H.pending;if(!p||p.seat!==seat||p.kind!==kind)return false;
    if(kind==='trump'){if(!SUITS.includes(val))return false;H.pending=null;p.res(val);return true}
    const card=H.hands[seat].find(c=>c.id===val);if(!card||!Omi.isLegal(H.hands[seat],H.trick,card))return false;
    H.pending=null;p.res(card);return true;
  };
  H.auto=()=>{const p=H.pending;if(!p)return;H.input(p.seat,p.kind,p.kind==='trump'?Bot.chooseTrump(H.hands[p.seat]):Bot.play(H.hands[p.seat],H.trick,s.tp,p.seat).id)};
  H.waitFor=(seat,kind)=>new Promise((res,rej)=>{H.pending={seat,kind,res,rej,t0:Date.now()}});
  H.abort=()=>{H.gen++;if(H.pending){const p=H.pending;H.pending=null;p.rej('cancel')}if(H.contRej){const r=H.contRej;H.contRej=H.contRes=null;r('cancel')}};
  H.destroy=()=>{H.abort();clearInterval(H.tickI)};
  H.cont=()=>{if(H.contRes)H.contRes()};
  H.tickI=setInterval(()=>{
    const p=H.pending;
    if(p){const st=s.seats[p.seat];const off=st&&st.h&&!st.on&&Date.now()-H.offAt[p.seat]>8000;if((S.timer&&Date.now()-p.t0>30500)||off)H.auto()}
    if(s.ph==='lobby'&&H.pubTbl){const rem=Math.max(0,Math.ceil((H.lobbyEnd-Date.now())/1000));if(rem===0||[1,2,3].every(i=>s.seats[i]))H.start();else if(rem!==s.as){s.as=rem;H.pub()}}
  },400);
  H.start=()=>{
    const used=new Set(s.seats.filter(Boolean).map(x=>x.a));
    const pool=Omi.shuffle(BOTS.map((b,i)=>i).filter(i=>!used.has(BOTS[i].avatar)));const isC=i=>['kasun','dilini','nuwan','sachini'].includes(BOTS[i].avatar)?1:0;pool.sort((a,b)=>isC(a)-isC(b));
    for(let i=1;i<4;i++)if(!s.seats[i])s.seats[i]={b:pool.pop()};
    H.run();
  };
  H.deal=async(deck,start,n)=>{let idx=start;for(let i=0;i<4;i++){const seat=(s.cl+i)%4;H.hands[seat].push(...deck.slice(idx,idx+n));idx+=n;s.nc[seat]+=n;H.pub();await H.wait(n*55+170)}await H.wait(250)};
  H.trickTalk=(w,done)=>{
    const ace=done.find(x=>x.card.r==='A'&&x.seat!==w);
    if(ace&&Math.random()<.55){H.say(H.speaker(i=>i!==ace.seat),'aceLost');return}
    if(!H.isBot(w)){const pt=(w+2)%4;if(H.isBot(pt)&&Math.random()<.5)H.say(pt,'trickWin');else if(Math.random()<.35)H.rx(H.speaker(i=>i%2!==w%2),pick(['😢','😡','🤔']))}
    else if(Math.random()<.28)H.say(w,'trickWin');else if(Math.random()<.2)H.rx(w,'😎');
  };
  H.round=async()=>{
    s.rn++;H.hands=[[],[],[],[]];H.trick=[];s.nc=[0,0,0,0];s.tk=[];s.tr=[0,0];s.tp=null;s.cl=(s.dl+1)%4;s.tu=null;s.ph='deal';s.rb=null;H.pub();
    const deck=Omi.shuffle(Omi.deck());
    await H.deal(deck,0,4);
    s.ph='trump';s.tu=s.cl;s.tl=H.isBot(s.cl)?0:(S.timer?30000:0);H.pub();
    let tp;if(H.isBot(s.cl)){await H.wait(1300);tp=Bot.chooseTrump(H.hands[s.cl])}else tp=await H.waitFor(s.cl,'trump');
    s.tp=tp;s.calls[s.cl]++;s.tu=null;s.ph='deal';H.pub();await H.wait(1300);
    await H.deal(deck,16,4);
    const strong=bots(i=>{const h=H.hands[i];return h.filter(c=>c.s===tp).length*2+h.filter(c=>c.r==='A').length>=7});
    if(strong.length&&Math.random()<.7)H.say(pick(strong),'goodHand');
    s.ph='play';let leader=s.cl;
    for(let n8=0;n8<8;n8++){
      H.trick=[];s.tk=[];
      for(let k=0;k<4;k++){
        const seat=(leader+k)%4,bot=H.isBot(seat);s.tu=seat;s.tl=bot?0:(S.timer?30000:0);H.pub();
        let card;if(bot){await H.wait(650+rand(550));card=Bot.play(H.hands[seat],H.trick,tp,seat)}else card=await H.waitFor(seat,'play');
        if(!Omi.isLegal(H.hands[seat],H.trick,card))card=Omi.legal(H.hands[seat],H.trick)[0];
        const prev=H.trick.length?H.trick[Omi.winnerIdx(H.trick,tp)]:null;
        H.hands[seat]=H.hands[seat].filter(c=>c.id!==card.id);s.nc[seat]--;H.trick.push({seat,card});s.tk.push([seat,card.id]);
        if(prev&&prev.seat!==seat&&prev.seat%2===seat%2&&card.s===tp&&H.trick[0].card.s!==tp&&Omi.beats(card,prev.card,tp)){
          const sp=H.isBot((seat+2)%4)?(seat+2)%4:H.speaker(i=>i!==seat);H.later(()=>H.say(sp,'badMove',true),450);
        }
        s.tu=null;
        H.pub();await H.wait(380);
      }
      await H.wait(900);
      const w=H.trick[Omi.winnerIdx(H.trick,tp)].seat;s.tr[w%2]++;s.pt[w]++;
      H.trickTalk(w,H.trick);s.cx=[s.cx[0]+1,w];s.tk=[];H.pub();await H.wait(900);leader=w;
    }
    const res=Omi.scoreRound(s.tr,s.cl%2,{kapothi:s.kp});H.rbN++;const rb={n:H.rbN,t:s.tr.slice()};
    if(res.tie){s.cr+=1;Object.assign(rb,{tie:1,cr:s.cr})}
    else{
      let p=res.points===Infinity?Math.max(s.tg-s.sc[res.winnerTeam],1):res.points;const carry=s.cr;s.cr=0;p+=carry;s.sc[res.winnerTeam]+=p;
      Object.assign(rb,{wt:res.winnerTeam,p,kap:res.kapothi?1:0,byC:res.byCaller?1:0,carry});
      H.say(H.speaker(i=>i%2===res.winnerTeam),res.kapothi?'kapothi':'roundWin',true);
      const lb=H.speaker(i=>i%2!==res.winnerTeam);if(lb>=0)H.later(()=>H.say(lb,'lose',true),1600);
    }
    s.rb=rb;s.ph='round';s.tu=null;H.pub();
    await new Promise((res2,rej)=>{const to=setTimeout(()=>{H.contRes=H.contRej=null;res2()},6500*SPD());H.contRes=()=>{clearTimeout(to);H.contRes=H.contRej=null;res2()};H.contRej=e=>{clearTimeout(to);rej(e)}});
  };
  H.run=async()=>{
    H.abort();
    Object.assign(s,{sc:[0,0],cr:0,dl:rand(4),rn:0,pt:[0,0,0,0],calls:[0,0,0,0],end:null,rb:null,tk:[],tr:[0,0],nc:[0,0,0,0],tp:null,tu:null,cl:null,ph:'start',tg:S.target,kp:S.kapothi,as:0,tl:0});
    H.hands=[[],[],[],[]];H.trick=[];H.pub();
    H.later(()=>H.say(H.speaker(),'start',true),900);
    try{
      await H.wait(1900);
      while(true){
        await H.round();
        if(s.sc[0]>=s.tg||s.sc[1]>=s.tg){H.endN++;s.ph='end';s.end={n:H.endN,w:s.sc[0]>s.sc[1]?0:1};s.tu=null;H.pub();return}
        s.dl=(s.dl+1)%4;
      }
    }catch(e){if(e!=='cancel')console.error(e)}
  };
  return H;
}

/* ================= CLIENT VIEW ================= */
let HOST=null;
const V={mode:'off',pub:null,mySeat:0,spect:false,hand:[],shown:[],myTurn:false,selected:null,evN:0,cxN:0,bannerN:0,endN:0,lastPh:null,seatSig:null,glowed:false,maxDef:0,kapUs:0,timerI:null};
const pos=s=>(s-V.mySeat+4)%4, myT=()=>V.mySeat%2;
function seatName(s){const st=V.pub&&V.pub.seats[s];if(!st)return'';if(st.b!==undefined)return(BOTS[st.b]||BOTS[0]).names[LI[S.lang]];if(s===V.mySeat&&!V.spect)return P.name||t('you');return cleanName(st.n)||'Player'}
function seatAv(s){const st=V.pub.seats[s];if(!st)return{a:'cool',photo:null};if(st.b!==undefined)return{a:(BOTS[st.b]||BOTS[0]).avatar,photo:null};return{a:AV[st.a]?st.a:'cool',photo:(s===V.mySeat&&!V.spect&&V.mode!=='client')||(s===V.mySeat&&!V.spect)?P.photo:null}}
const seatSig=p=>JSON.stringify(p.seats.map(x=>x&&[x.b,x.n,x.a,x.h]))+V.mySeat+S.lang+V.spect;
function buildSeats(){
  const p=V.pub;
  for(let q=0;q<4;q++)$('#seat'+q).innerHTML='';
  for(let s=0;s<4;s++){const st=p.seats[s];if(!st)continue;const el=$('#seat'+pos(s));const {a,photo}=seatAv(s);
    el.innerHTML=`<div class="avatar team${s%2===myT()?0:1}" style="--avbg:${AVBG[a]}"><div class="ph">${avatarHTML(a,photo)}</div><span class="chip dealer">D</span><span class="chip caller">T</span></div><div class="pname"></div>${pos(s)?'<div class="minihand"></div>':''}<div class="bubble"></div>`;
    el.querySelector('.pname').textContent=seatName(s);}
  V.seatSig=seatSig(p);
}
function renderSeats(){const p=V.pub;for(let s=0;s<4;s++){const el=$('#seat'+pos(s)),st=p.seats[s];el.classList.toggle('turn',p.tu===s);el.classList.toggle('isDealer',p.ph!=='start'&&p.dl===s);el.classList.toggle('isCaller',p.cl===s);el.classList.toggle('off',!!(st&&st.h&&!st.on));const cc=el.querySelector('.chip.caller');if(cc)cc.textContent=p.tp&&p.cl===s?SYM[p.tp]:'T'}}
function renderMini(){const p=V.pub;for(let s=0;s<4;s++){if(!pos(s))continue;const m=$(`#seat${pos(s)} .minihand`);if(m)m.innerHTML='<i></i>'.repeat(Math.max(0,Math.min(8,p.nc[s]|0)))}}
function setNum(sel,v){const e=$(sel);if(e.textContent!==String(v)){e.textContent=v;const p=e.parentElement;p.classList.remove('bump');void p.offsetWidth;p.classList.add('bump')}}
function renderHud(){
  const p=V.pub;if(!p)return;const m=myT();
  setNum('#scA',p.sc[m]);setNum('#scB',p.sc[1-m]);$('#tgt').textContent=p.tg;$('#trA').textContent=p.tr[m];$('#trB').textContent=p.tr[1-m];
  const tb=$('#trumpBox');$('#trumpSym').textContent=p.tp?SYM[p.tp]:'?';tb.className='trumpbox'+(p.tp?' set'+(RED[p.tp]?' red':''):'');
  const c=$('#carry');c.hidden=!p.cr;c.textContent=p.cr?'+'+p.cr:'';
}
const curTrick=()=>V.pub.tk.map(([seat,id])=>({seat,card:cardFromId(id)})).filter(x=>x.card);
function sortHand(){const tp=V.pub&&V.pub.tp,o=s=>s===tp?-1:SUITS.indexOf(s);V.hand.sort((a,b)=>o(a.s)-o(b.s)||Omi.v(b)-Omi.v(a))}
function renderHand(){
  const el=$('#hand');el.innerHTML='';if(V.spect)return;const h=V.hand,n=h.length,tp=V.pub&&V.pub.tp;
  const legal=V.myTurn?Omi.legal(h,curTrick()).map(c=>c.id):null;
  h.forEach((c,i)=>{const d=cardEl(c);d.dataset.id=c.id;const off=i-(n-1)/2;
    d.style.setProperty('--r',(off*3.2)+'deg');d.style.setProperty('--y',(off*off*1.5)+'px');
    if(tp&&c.s===tp)d.classList.add('trumpc');
    if(legal){d.classList.add(legal.includes(c.id)?'playable':'dim');d.tabIndex=0}
    if(V.selected===c.id)d.classList.add('sel');
    d.addEventListener('pointerdown',onCardDown);
    d.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&V.myTurn){e.preventDefault();tryPlay(c)}});
    el.append(d)});
}
function status(key,vars){V.st=[key,vars];$('#statusText').textContent=t(key,vars);$('#status').classList.toggle('mine',key==='yourTurn'||key==='yourTurnTouch'||key==='chooseTrump')}
function updStatus(){
  const p=V.pub;let k=null,v;
  if(p.ph==='start')k='gameStart';
  else if(p.ph==='deal')k='dealing';
  else if(p.ph==='trump'){if(p.tu===V.mySeat&&!V.spect)k='chooseTrump';else{k='choosingTrump';v={n:seatName(p.tu)}}}
  else if(p.ph==='play'&&p.tu!=null){if(p.tu===V.mySeat&&!V.spect)k=touchUI()?'yourTurnTouch':'yourTurn';else{k='turnOf';v={n:seatName(p.tu)}}}
  else if(p.ph==='round'&&p.rb)k=p.rb.tie?'roundTie':(p.rb.wt===myT()?'roundUs':'roundThem');
  if(V.spect&&p.ph==='play')k='spect',v=null;
  if(k)status(k,v);
}

/* ---- comments, reactions ---- */
function bubble(q,text){const b=$(`#seat${q} .bubble`);if(!b)return;b.textContent=text;b.classList.add('show');clearTimeout(b._t);b._t=setTimeout(()=>b.classList.remove('show'),2800)}
function floatReact(q,emo){
  if(!t('reacts')[emo])return;const av=$(`#seat${q} .avatar`);if(!av)return;
  const seat=(q+V.mySeat)%4;const a=V.pub&&V.pub.seats[seat]?seatAv(seat).a:P.avatar;
  const r=relRect(av);const el=document.createElement('div');el.className='react';
  el.innerHTML=(OmiChars.CHARS[a]&&EMO_KEY[emo]?`<div class="emo" style="--avbg:${AVBG[a]}">${emoteFace(a,emo)}</div>`:`<span class="e">${emo}</span>`)+`<span class="l"></span>`;
  el.querySelector('.l').textContent=t('reacts')[emo];$('#fx').append(el);
  const tr=relRect($('#table'));let x=r.x+r.w/2-el.offsetWidth/2,y=r.y+r.h/2-el.offsetHeight/2;
  x=Math.max(4,Math.min(tr.w-el.offsetWidth-4,x));y=Math.max(4,Math.min(tr.h-el.offsetHeight-4,y));
  el.style.left=x+'px';el.style.top=y+'px';
  el.animate([{transform:'scale(.2) rotate(-12deg)',opacity:0},{transform:'scale(1.15) rotate(4deg)',opacity:1,offset:.14},{transform:'scale(1) rotate(0)',opacity:1,offset:.24},{transform:'scale(1) translateY(-6px)',opacity:1,offset:.8},{transform:'scale(.9) translateY(-34px)',opacity:0}],{duration:2400,easing:'ease-out'}).onfinish=()=>el.remove();
}
function showEvent(ev){
  const [,seat,key,val]=ev;if(typeof seat!=='number')return;
  if(key==='@'){if(seat>=0&&seat<4)floatReact(pos(seat),val);return}
  if(!S.comments||!C[key]||!C[key][val])return;const text=C[key][val][LI[S.lang]];
  if(seat<0||seat>3)toast('📣 '+text);else bubble(pos(seat),text);
}
let lastReact=0;
function buildReactPanel(){const p=$('#reactPanel');const R=t('reacts');const me=OmiChars.CHARS[P.avatar]?P.avatar:null;p.innerHTML=Object.keys(R).map(e=>`<button data-e="${e}" aria-label="${esc(R[e])}"><div class="pf" style="--avbg:${me?AVBG[me]:'transparent'}">${me?emoteFace(me,e):e}</div><small></small></button>`).join('');$('#reactBtn').innerHTML=me?`<span style="display:block;width:100%;height:100%;background:${AVBG[me]}">${emoteFace(me,'😂')}</span>`:'😂';
  p.querySelectorAll('button').forEach(b=>{b.querySelector('small').textContent=R[b.dataset.e];b.onclick=()=>{
    if(Date.now()-lastReact<900||V.spect)return;lastReact=Date.now();p.classList.remove('show');const e=b.dataset.e;floatReact(0,e);sfx('pop');
    if(V.mode==='off'&&HOST)HOST.humanRx(V.mySeat,e);else netEmit('rx',{e});
  }})}
$('#reactBtn').onclick=()=>{$('#reactPanel').classList.toggle('show');sfx('click')};
function splash(html){const s=$('#splash');s.innerHTML=html;s.className='';void s.offsetWidth;s.className='show'}

/* ---- animations ---- */
function flyBack(from,to){const el=document.createElement('div');el.className='card back fly';$('#fx').append(el);
  const w=el.offsetWidth,h=el.offsetHeight,fx=from.x+from.w/2-w/2,fy=from.y+from.h/2-h/2,tx=to.x+to.w/2-w/2,ty=to.y+to.h/2-h/2;
  el.style.left=tx+'px';el.style.top=ty+'px';
  el.animate([{transform:`translate(${fx-tx}px,${fy-ty}px) scale(.9)`,opacity:1},{transform:`translate(0,0) rotate(${rand(40)-20}deg) scale(.55)`,opacity:.15}],{duration:340*SPD(),easing:'cubic-bezier(.2,.7,.3,1)'}).onfinish=()=>el.remove()}
function seatTarget(q){return q===0?$('#hand'):($(`#seat${q} .minihand`)||$(`#seat${q} .avatar`)||$('#trick'))}
function dealAnim(s,d){const from=relRect($('#trick')),to=relRect(seatTarget(pos(s)));for(let k=0;k<d;k++)setTimeout(()=>{flyBack(from,to);sfx('deal')},k*55*SPD())}
function clearSlots(){[0,1,2,3].forEach(q=>$('#slot'+q).innerHTML='');V.shown=[];V.glowed=false}
function placeCard(seat,card,anim){
  const q=pos(seat);const src=(seat===V.mySeat&&!V.spect)?($(`#hand [data-id="${card.id}"]`)||$('#hand')):seatTarget(q);const sr=relRect(src);
  const slot=$('#slot'+q);slot.innerHTML='';const el=cardEl(card);if(card.s===V.pub.tp)el.classList.add('trumpc');slot.append(el);
  const rot=rand(17)-8;el.style.transform=`rotate(${rot}deg)`;if(!anim)return;const dr=relRect(slot);
  el.animate([{transform:`translate(${sr.x+sr.w/2-(dr.x+dr.w/2)}px,${sr.y+sr.h/2-(dr.y+dr.h/2)}px) rotate(${rot+(q%2?90:0)}deg) scale(${q===0?1.1:.45})`},{transform:`rotate(${rot}deg)`}],{duration:380*SPD(),easing:'cubic-bezier(.2,.8,.25,1.06)'});
  sfx('card');
}
function syncTrick(tk,anim){
  const same=V.shown.length<=tk.length&&V.shown.every((x,i)=>x[0]===tk[i][0]&&x[1]===tk[i][1]);
  if(!same){clearSlots();anim=false}
  for(let i=V.shown.length;i<tk.length;i++){const c=cardFromId(tk[i][1]);if(!c)continue;placeCard(tk[i][0],c,anim);V.shown.push(tk[i])}
  if(tk.length===4&&!V.glowed){V.glowed=true;const w=tk[Omi.winnerIdx(curTrick(),V.pub.tp)][0];setTimeout(()=>{if(V.shown.length!==4)return;const e=$(`#slot${pos(w)} .card`);if(e){e.classList.add('winc');sfx('trick')}},400*SPD())}
}
function collectAnim(w){
  if(w<0||w>3){clearSlots();return}
  const av=$(`#seat${pos(w)} .avatar`);if(!av){clearSlots();return}const to=relRect(av);
  [0,1,2,3].forEach(q=>{const el=$(`#slot${q} .card`);if(!el)return;const r=relRect(el);el.remove();el.classList.add('fly');el.style.left=r.x+'px';el.style.top=r.y+'px';$('#fx').append(el);
    const dx=to.x+to.w/2-(r.x+r.w/2),dy=to.y+to.h/2-(r.y+r.h/2);
    el.animate([{transform:el.style.transform,opacity:1},{transform:`translate(${dx}px,${dy}px) scale(.2) rotate(25deg)`,opacity:0}],{duration:420*SPD(),easing:'ease-in',fill:'forwards'}).onfinish=()=>el.remove()});
  clearSlots();
  setTimeout(()=>{const p=document.createElement('div');p.className='plus1';p.textContent='+1';$('#fx').append(p);p.style.left=(to.x+to.w-6)+'px';p.style.top=(to.y-6)+'px';
    p.animate([{transform:'scale(.4)',opacity:0},{transform:'scale(1.3)',opacity:1,offset:.3},{transform:'translateY(-30px)',opacity:0}],{duration:1000}).onfinish=()=>p.remove()},380*SPD());
}

/* ---- main render from authoritative state ---- */
function onPub(p,hand){
  const prev=V.pub;V.pub=p;
  if(hand){V.hand=hand.slice();sortHand()}
  if(p.ph==='lobby'){renderLobby(p);V.lastPh='lobby';return}
  if(!$('#game').classList.contains('active')){showScreen('game');$('#results').classList.remove('show');V.seatSig=null}
  draw(prev&&prev.ph!=='lobby'?prev:null,p);
}
function draw(prev,p){
  if(V.seatSig!==seatSig(p))buildSeats();
  if(!prev){V.evN=p.ev[0];V.cxN=p.cx[0];V.bannerN=p.rb?p.rb.n:0;V.endN=p.end?p.end.n:0;clearSlots()}
  if(p.ph==='start'&&V.lastPh!=='start'){V.maxDef=0;V.kapUs=0;$('#results').classList.remove('show');$('#roundBanner').classList.remove('show');clearSlots();
    splash(`<div class="txt">${esc(t('gameStart'))}</div>`);speak(t('gameStart'));sfx('trump')}
  V.lastPh=p.ph;
  renderHud();renderSeats();
  if(prev){for(let s=0;s<4;s++){const d=(p.nc[s]|0)-(prev.nc[s]|0);if(d>0&&!p.tk.length)dealAnim(s,d)}}
  if(prev&&!prev.tp&&p.tp){splash(`<div class="big ${RED[p.tp]?'red':''}">${SYM[p.tp]}</div><div class="txt">${esc(t('trumpIs',{s:t('suit')[p.tp]}))}</div>`);sfx('trump');speak(t('trumpIs',{s:t('suit')[p.tp]}));sortHand()}
  if(p.cx[0]!==V.cxN){V.cxN=p.cx[0];if(prev)collectAnim(p.cx[1]);else clearSlots()}
  syncTrick(p.tk,!!prev);
  if(p.ev[0]!==V.evN){V.evN=p.ev[0];if(prev)showEvent(p.ev)}
  const pickMine=p.ph==='trump'&&p.tu===V.mySeat&&!V.spect&&!p.tp;
  if(pickMine&&!$('#trumpPick').classList.contains('show'))showTrumpPick();if(!pickMine)$('#trumpPick').classList.remove('show');
  const mine=p.ph==='play'&&p.tu===V.mySeat&&!V.spect&&p.tk.length<4;
  if(mine&&!V.myTurn){V.myTurn=true;V.selected=null;startTimer(p.tl);speak(t('yourTurn'))}else if(!mine&&V.myTurn){V.myTurn=false;stopTimer()}
  if(p.rb&&p.rb.n!==V.bannerN){V.bannerN=p.rb.n;if(!p.rb.tie&&p.rb.kap&&p.rb.wt===myT())V.kapUs++;if(prev)showBanner(p.rb)}
  if(p.ph!=='round')$('#roundBanner').classList.remove('show');
  V.maxDef=Math.max(V.maxDef,p.sc[1-myT()]-p.sc[myT()]);
  if(p.end&&p.end.n!==V.endN){V.endN=p.end.n;if(prev)showResults(p)}
  updStatus();renderMini();renderHand();
}

/* ---- user input ---- */
let drag=null;
function onCardDown(e){
  if(!V.myTurn)return;const el=e.currentTarget;drag={el,id:el.dataset.id,x:e.clientX,y:e.clientY,type:e.pointerType,moved:false};
  try{el.setPointerCapture(e.pointerId)}catch(_){}
  el.addEventListener('pointermove',onCardMove);
  el.addEventListener('pointerup',onCardUp,{once:true});
  el.addEventListener('pointercancel',()=>{el.removeEventListener('pointermove',onCardMove);el.style.translate='';drag=null},{once:true});
}
function onCardMove(e){if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.abs(dx)>6||Math.abs(dy)>6)drag.moved=true;if(drag.moved)drag.el.style.translate=`${dx*.5}px ${Math.min(0,dy)}px`}
function onCardUp(e){
  const d=drag;drag=null;if(!d)return;d.el.removeEventListener('pointermove',onCardMove);d.el.style.translate='';
  if(!V.myTurn)return;const card=V.hand.find(c=>c.id===d.id);if(!card)return;const dy=e.clientY-d.y;
  if(!Omi.isLegal(V.hand,curTrick(),card)){if(!d.moved||dy<-30){d.el.animate([{translate:'0'},{translate:'-8px 0'},{translate:'8px 0'},{translate:'-5px 0'},{translate:'0'}],{duration:300});toast(t('followSuit'));sfx('err')}return}
  if(dy<-45||(d.type==='mouse'&&!d.moved)||(V.selected===d.id&&!d.moved))submitCard(card);
  else if(!d.moved){V.selected=d.id;renderHand();sfx('click')}
}
function tryPlay(card){if(!Omi.isLegal(V.hand,curTrick(),card)){toast(t('followSuit'));sfx('err');return}submitCard(card)}
function submitCard(card){if(!V.myTurn)return;V.myTurn=false;V.selected=null;stopTimer();renderHand();act('play',card.id);
  const g=V.pub.v;setTimeout(()=>{if(V.pub&&V.pub.v===g&&V.pub.tu===V.mySeat&&V.pub.ph==='play'){V.myTurn=true;renderHand()}},4000)}
function stopTimer(){clearInterval(V.timerI);V.timerI=null;$('#timerBar').style.width='0'}
function startTimer(tl){stopTimer();if(!tl)return;const t0=Date.now();V.timerI=setInterval(()=>{const f=(Date.now()-t0)/tl;$('#timerBar').style.width=Math.min(100,f*100)+'%';if(f>=1)stopTimer()},150)}
function showTrumpPick(){
  const p=$('#trumpPick'),h=V.hand,SN=t('suit');
  p.innerHTML=`<h3>${t('chooseTrump')}</h3><p>${t('chooseTrumpSub')}</p><div class="suits">${SUITS.map(s=>`<button class="suitbtn ${RED[s]?'red':''}" data-s="${s}"><span>${SYM[s]}</span><small>${SN[s]}</small><em>×${h.filter(c=>c.s===s).length}</em></button>`).join('')}</div>`;
  p.classList.add('show');speak(t('chooseTrump'));
  p.querySelectorAll('.suitbtn').forEach(b=>b.onclick=()=>{p.classList.remove('show');sfx('click');act('trump',b.dataset.s)});
}
function showBanner(rb){
  const b=$('#roundBanner'),m=myT();let title,why,pts,cls;
  if(rb.tie){title=t('roundTie');why=t('whyTie',{c:rb.cr});pts='0';cls='tie';sfx('round')}
  else{const us=rb.wt===m;title=rb.kap?t(us?'kapothiUs':'kapothiThem'):t(us?'roundUs':'roundThem');
    why=(rb.kap?t('whyKap')+' ':'')+(rb.kap&&V.pub.kp!=='none'?'':t(rb.byC?'whyCaller':'whyDefender'))+(rb.carry?' '+t('carryAdd',{c:rb.carry}):'');
    pts='+'+rb.p;cls=us?'teamA':'teamB';sfx(us?'round':'lose')}
  b.innerHTML=`<div class="rb-title">${title}</div><div class="rb-tricks">${t('us')} <b>${rb.t[m]}</b> – <b>${rb.t[1-m]}</b> ${t('them')}</div><div class="rb-why">${why}</div><div class="rb-pts ${cls}">${pts}</div><br><button class="btn yellow" id="nextR">${V.mode==='net'&&!NET.isHost?'OK 👍':t('nextRound')}</button>`;
  b.classList.add('show');
  b.querySelector('#nextR').onclick=()=>{sfx('click');contRound();b.classList.remove('show')};
}

/* ---- results ---- */
function awardIds(){const a=[];if(ST.wins>=10)a.push('champ');if(ST.losses>=5)a.push('unlucky');if(ST.comebacks>=1)a.push('comeback');if(ST.whitewash>=1)a.push('loser');if(ST.kapothis>=1)a.push('master');if(ST.played>=50)a.push('legend');return a}
function showResults(p){
  stopTimer();$('#roundBanner').classList.remove('show');
  const m=myT(),win=!V.spect&&p.end.w===m;
  if(!V.spect){const before=awardIds();ST.played++;if(win){ST.wins++;ST.streak++;ST.best=Math.max(ST.best,ST.streak);if(V.maxDef>=5)ST.comebacks++}else{ST.losses++;ST.streak=0;if(p.sc[m]===0)ST.whitewash++}
    ST.kapothis+=V.kapUs;rollPeriods();ST.wkP=(ST.wkP|0)+1;ST.moP=(ST.moP|0)+1;if(win){ST.wkW=(ST.wkW|0)+1;ST.moW=(ST.moW|0)+1}saveST();awardIds().filter(a=>!before.includes(a)).forEach((a,i)=>setTimeout(()=>toast(t('newAward',{a:t('awardsList')[a][0]})),1500+i*2600))}
  const q=pick(win?C.gameWin:C.lose)[LI[S.lang]];
  const order=[V.mySeat,(V.mySeat+2)%4,(V.mySeat+1)%4,(V.mySeat+3)%4];
  const rp=s=>{const {a,photo}=seatAv(s);return `<div class="rp ${s%2===m?'':'t1'}"><div class="avs" style="--avbg:${AVBG[a]}">${avatarHTML(a,photo)}</div><div><b>${esc(seatName(s))}</b><small>${t('tricksTaken',{n:p.pt[s]})} · ${t('calledN',{n:p.calls[s]})}</small></div></div>`};
  const canRe=V.mode==='off'||NET.isHost;
  const R=$('#results');
  R.innerHTML=`<div class="res-card"><div class="res-emoji ${win?'win':'lose'}">${win?'🏆':'😭'}</div><h2>${win?t('weWin'):t('theyWin')}</h2><div class="res-quote">“${esc(q)}”</div>
   <div class="res-score"><div class="teamA">${t('us')}<b>${p.sc[m]}</b></div><span>–</span><div class="teamB">${t('them')}<b>${p.sc[1-m]}</b></div></div>
   <div class="res-players">${order.map(rp).join('')}</div>
   ${canRe?'':`<p class="res-quote">${t('rematchWait')}</p>`}
   <div class="mbtns">${canRe?`<button class="btn yellow" id="rRe">${t('rematch')}</button>`:''}<button class="btn emerald" id="rInv">${t('invite')}</button><button class="btn ghost" id="rHome">${t('home')}</button></div></div>`;
  R.classList.add('show');
  if(canRe)R.querySelector('#rRe').onclick=()=>{sfx('click');R.classList.remove('show');rematch()};
  R.querySelector('#rHome').onclick=()=>{sfx('click');goHome()};R.querySelector('#rInv').onclick=invite;
  if(win){sfx('win');confetti();speak(t('weWin'))}else{sfx('lose');for(let i=0;i<22;i++){const f=document.createElement('div');f.className='fall';f.textContent=pick(['😭','💀','🤦','😩']);f.style.left=rand(96)+'%';f.style.animationDuration=(2.5+Math.random()*2.5)+'s';f.style.animationDelay=(Math.random()*2)+'s';R.append(f)}}
}
async function invite(){
  if(NET.code){shareInvite();return}
  const url=location.href.split('#')[0],text=t('inviteText');
  try{if(navigator.share){await navigator.share({title:'OMI LANKA',text,url});return}}catch(e){return}
  try{await navigator.clipboard.writeText(text+' '+url);toast(t('copied'))}catch(e){toast(url)}
}

/* ================= ONLINE (Socket.IO game server) ================= */
Object.assign(T.si,{reconnecting:'Connection එක නැති වුණා. ආයෙත් සම්බන්ධ වෙනවා...',roomClosed:'Room එක වැහුණා.',serverDown:'Online server එකට සම්බන්ධ වෙන්න බෑ. දැනට Bots එක්ක ගහමු!',lobbyNote:'යාළුවන්ට invite link එක යවන්න, නැත්නම් room code එක දෙන්න.',codeCopied:'Invite link එක කොපි වුණා! 📨',
  account:'ගිණුම',guestNote:'ඔයා දැන් Guest. Sign in වුණොත් වෙන phone/computer එකකින් ගැහුවත් ලකුණු නැති වෙන්නේ නෑ.',signInGoogle:'Google එකෙන් sign in වෙන්න',emailPh:'ඔයාගේ email එක',sendLink:'Email link එකක් එවන්න',linkSent:'Email එක check කරන්න — sign in link එකක් ආවා! 📧',signedInAs:'Sign in වෙලා ඉන්නේ: {e}',signOut:'Sign out',
  reportBtn:'🚩 Report කරන්න',reported:'Report එක යැව්වා. ස්තූතියි!',reportTitle:'මේ player ව report කරන්නද?'});
Object.assign(T.sl,{reconnecting:'Connection eka nathi wuna. Ayeth sambandha wenawa...',roomClosed:'Room eka wahuna.',serverDown:'Online server ekata sambandha wenna bae. Danata Bots ekka gahamu!',lobbyNote:'Yaaluwanta invite link eka yawanna, nathnam room code eka denna.',codeCopied:'Invite link eka copy wuna! 📨',
  account:'Ginuma',guestNote:'Oya dan Guest. Sign in wunoth wena phone/computer ekakin gahuwath lakunu nathi wenne nae.',signInGoogle:'Google eken sign in wenna',emailPh:'Oyage email eka',sendLink:'Email link ekak ewanna',linkSent:'Email eka check karanna — sign in link ekak awa! 📧',signedInAs:'Sign in wela inne: {e}',signOut:'Sign out',
  reportBtn:'🚩 Report karanna',reported:'Report eka yawwa. Sthuthi!',reportTitle:'Me player wa report karannada?'});
Object.assign(T.en,{reconnecting:'Connection lost. Reconnecting...',roomClosed:'The room was closed.',serverDown:'Can’t reach the online server right now. Let’s play with bots!',lobbyNote:'Send your friends the invite link, or give them the room code.',codeCopied:'Invite link copied! 📨',
  account:'Account',guestNote:'You’re playing as a guest. Sign in to keep your stats on any phone or computer.',signInGoogle:'Sign in with Google',emailPh:'Your email',sendLink:'Email me a sign-in link',linkSent:'Check your email for a sign-in link! 📧',signedInAs:'Signed in as {e}',signOut:'Sign out',
  reportBtn:'🚩 Report player',reported:'Report sent. Thank you!',reportTitle:'Report this player?'});
const NET={sock:null,connected:false,code:null,isHost:false,pubTbl:false,signedIn:false,email:null,token:null,pendingJoin:null};
const prof=()=>({name:cleanName(P.name),avatar:P.avatar,settings:{target:S.target,kapothi:S.kapothi,timer:S.timer,speed:S.speed}});
function netEmit(ev,data,cb){if(NET.sock&&NET.connected)NET.sock.emit(ev,data,cb)}
function connect(){
  if(typeof io!=='function')return;
  if(NET.sock){NET.sock.removeAllListeners();NET.sock.disconnect()}
  const s=io({auth:{cid:CID,token:NET.token||undefined},transports:['websocket','polling'],reconnectionDelayMax:4000});NET.sock=s;
  s.on('connect',()=>{NET.connected=true;
    const code=NET.pendingJoin||(V.mode==='net'?NET.code:null);NET.pendingJoin=null;
    if(code)s.emit('join',Object.assign({code},prof()),r=>{if(r&&r.error){toast(t('noRoom'));goHome()}else enterNet(r.code)})});
  s.on('disconnect',()=>{NET.connected=false;if(V.mode==='net')toast(t('reconnecting'))});
  s.on('connect_error',e=>{NET.connected=false;if(e&&e.message==='banned')toast('🚫')});
  s.on('hello',h=>{NET.signedIn=!!h.signedIn;NET.email=h.email||null;netEmit('profile',prof())});
  s.on('state',m=>{if(V.mode!=='net'||!m||!m.g||!Array.isArray(m.g.seats))return;
    NET.code=m.code;NET.isHost=!!m.host;NET.pubTbl=!!m.pub;V.isHost=NET.isHost;
    const ms=typeof m.you==='number'?m.you:-1;const prevSeat=V.mySeat;V.spect=ms<0&&m.g.ph!=='lobby';V.mySeat=ms<0?0:ms;if(prevSeat!==V.mySeat)V.seatSig=null;
    onPub(m.g,(m.hand||[]).map(cardFromId).filter(Boolean))});
  s.on('rx',m=>{if(V.mode==='net'&&V.pub&&m&&typeof m.seat==='number'&&m.seat>=0&&m.seat<4)floatReact(pos(m.seat),m.e)});
  s.on('closed',()=>{if(V.mode==='net'){toast(t('roomClosed'));goHome()}});
}
function enterNet(code){NET.code=code;try{history.replaceState(null,'','/?room='+code)}catch(e){}}
function requireNet(){if(!NET.connected){openModal(`<h2>${t('onlineTitle')}</h2><p>${t('serverDown')}</p><div class="mbtns"><button class="btn yellow" id="obots">${t('playBots')}</button></div>`,m=>m.querySelector('#obots').onclick=()=>{closeModal();startLocal()});return false}return true}
function act(kind,val){if(V.mode==='off'){if(HOST)HOST.input(V.mySeat,kind,val)}else netEmit('act',{kind,val})}
function contRound(){if(V.mode==='off'){if(HOST)HOST.cont()}else if(NET.isHost)netEmit('cont')}
function rematch(){if(V.mode==='off'){if(HOST)HOST.run()}else netEmit('rematch')}
const inviteLink=()=>location.origin+'/?room='+NET.code;

/* ================= LOBBY ================= */
function renderLobby(p){
  showScreen('lobby');$('#lbCode').textContent=NET.code||'';$('#lbKind').textContent=t(NET.pubTbl?'publicTbl':'privateTbl');
  const me=V.mySeat,mt=me%2;
  $$('.lb-seat').forEach(el=>{const s=+el.dataset.s,st=p.seats[s];el.className='lb-seat';el.onclick=null;
    if(!st){el.classList.add('empty');const can=me>=1&&s>=1;if(can){el.classList.add('can');el.onclick=()=>{sfx('click');netEmit('sit',{s})}}
      el.innerHTML=`<div class="avatar team${s%2===mt?0:1}">➕</div><b>${t('emptySeat')}</b><small>${can?t('tapSit'):''}</small>`;return}
    const a=AV[st.a]?st.a:'cool',mine=s===me;
    el.innerHTML=`<div class="avatar team${s%2===mt?0:1}" style="--avbg:${AVBG[a]}"><div class="ph">${avatarHTML(a,mine?P.photo:null)}</div></div><b></b><small>${s===0?t('hostTag'):''}${mine?(s===0?' · ':'')+t('youTag'):''}</small>`;
    el.querySelector('b').textContent=mine?(P.name||t('you')):(cleanName(st.n)||'Player')});
  const full=[1,2,3].every(i=>p.seats[i]);
  $('#lbStatus').textContent=p.as>0?t('autoStart',{s:p.as}):(NET.isHost?'':t('waitingHost'));
  const b=$('#lbStart');b.hidden=!NET.isHost;b.textContent=full?t('startGame'):t('startBots');
}
$('#lbStart').onclick=()=>{if(NET.isHost){sfx('click');netEmit('start')}};
async function shareInvite(){const url=inviteLink(),text=t('inviteCode',{c:NET.code});
  try{if(navigator.share){await navigator.share({title:'OMI LANKA',text,url});return}}catch(e){return}
  try{await navigator.clipboard.writeText(text+' '+url);toast(t('codeCopied'))}catch(e){toast(url)}}
$('#lbCopy').onclick=shareInvite;
$('#lbLeave').onclick=()=>{sfx('click');goHome()};

/* ================= MODES ================= */
function resetView(mode){
  stopTimer();closeModal();$('#results').classList.remove('show');$('#roundBanner').classList.remove('show');$('#trumpPick').classList.remove('show');$('#reactPanel').classList.remove('show');$('#fx').innerHTML='';
  Object.assign(V,{mode,pub:null,mySeat:0,spect:false,hand:[],shown:[],myTurn:false,selected:null,lastPh:null,seatSig:null,glowed:false,maxDef:0,kapUs:0,isHost:false});
  [0,1,2,3].forEach(q=>{$('#slot'+q).innerHTML='';$('#seat'+q).innerHTML=''});buildReactPanel();
}
function leaveNet(){if(V.mode==='net')netEmit('leave');NET.code=null;NET.isHost=false;try{if(location.search)history.replaceState(null,'','/')}catch(e){}}
function startLocal(){
  if(HOST){HOST.destroy();HOST=null}leaveNet();resetView('off');
  HOST=makeHost({seats:[{n:cleanName(P.name),a:P.avatar,h:1,on:1},null,null,null],onPub:H=>onPub(H.view(),H.hands[0])});
  showScreen('game');HOST.start();
}
function netStart(ev,extra){
  if(!requireNet())return;if(HOST){HOST.destroy();HOST=null}leaveNet();resetView('net');
  if(ev!=='create'||!extra||!extra.solo){showScreen('lobby');$('#lbCode').textContent='·····';$('#lbStatus').textContent=t(ev==='quick'?'searching':'connecting');$('#lbStart').hidden=true;$$('.lb-seat').forEach(e=>e.innerHTML='')}
  NET.sock.emit(ev,Object.assign(prof(),extra||{}),r=>{if(!r||r.error){toast(t(r&&r.error==='noRoom'?'noRoom':'roomErr'));goHome();return}enterNet(r.code)});
}
function playNow(){if(NET.connected)netStart('create',{solo:true});else startLocal()}
function createRoom(){netStart('create',{solo:false})}
function joinRoom(code){netStart('join',{code})}
function quickMatch(){netStart('quick')}
function goHome(){if(HOST){HOST.destroy();HOST=null}leaveNet();resetView('off');showScreen('home');rotateWelcome(true);renderChip()}

/* tap another player's avatar to report them (online games) */
$('#table').addEventListener('click',e=>{
  if(V.mode!=='net'||!V.pub)return;const seatEl=e.target.closest('.seat');if(!seatEl||!e.target.closest('.avatar'))return;
  const q=+seatEl.id.slice(4);const s=(q+V.mySeat)%4;const st=V.pub.seats[s];if(!st||!st.h||s===V.mySeat)return;
  openModal(`<h2>${t('reportTitle')}</h2><p><b></b></p><div class="mbtns"><button class="btn coral" id="rp">${t('reportBtn')}</button></div>`,m=>{m.querySelector('p b').textContent=seatName(s);
    m.querySelector('#rp').onclick=()=>{netEmit('report',{seat:s},()=>{});closeModal();toast(t('reported'))}});
});
/* ================= MODALS & HOME ================= */
function openModal(html,onMount){LB.open=false;const m=$('#modal');m.innerHTML=`<button class="x" aria-label="Close">✕</button>`+html;$('#modalbg').classList.add('show');m.querySelector('.x').onclick=closeModal;if(onMount)onMount(m)}
function closeModal(){LB.open=false;$('#modalbg').classList.remove('show')}
$('#modalbg').addEventListener('click',e=>{if(e.target.id==='modalbg')closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
function seg(key,opts){return `<div class="seg" data-key="${key}">${opts.map(([v,l])=>`<button data-v="${v}" class="${String(S[key])===String(v)?'on':''}">${l}</button>`).join('')}</div>`}
function openSettings(){
  const onoff=k=>seg(k,[[true,t('on')],[false,t('off')]]);
  openModal(`<h2>⚙️ ${t('settings')}</h2>
    <div class="srow"><span>${t('language')}</span>${seg('lang',[['si','සිංහල'],['sl','Singlish'],['en','English']])}</div>
    <div class="srow"><span>${t('comments')}</span>${onoff('comments')}</div>
    <div class="srow"><span>${t('sound')}</span>${onoff('sound')}</div>
    <div class="srow"><span>${t('voice')}</span>${onoff('voice')}<div class="note">${t('voiceNote')}</div></div>
    <div class="srow"><span>${t('speed')}</span>${seg('speed',[['slow',t('slow')],['normal',t('normal')],['fast',t('fast')]])}</div>
    <div class="srow"><span>${t('timer')}</span>${onoff('timer')}</div>
    <div class="srow"><span>${t('target')}</span>${seg('target',[[5,'5'],[10,'10'],[15,'15']])}</div>
    <div class="srow"><span>${t('kapothiRule')}</span>${seg('kapothi',[['3',t('kap3')],['game',t('kapGame')],['none',t('kapNone')]])}<div class="note">${t('kapNote')}</div></div>
    <div class="mbtns"><button class="btn ghost" id="toRules">${t('openRules')}</button></div>`,m=>{
      m.querySelectorAll('.seg').forEach(sg=>sg.querySelectorAll('button').forEach(b=>b.onclick=()=>{
        const k=sg.dataset.key;let v=b.dataset.v;if(v==='true')v=true;else if(v==='false')v=false;else if(k==='target')v=+v;
        S[k]=v;saveS();sfx('click');if(k==='lang')applyLang();
        if(HOST&&HOST.s.ph==='lobby'){HOST.s.tg=S.target;HOST.s.kp=S.kapothi;HOST.pub()}
        openSettings();
      }));
      m.querySelector('#toRules').onclick=openRules;
  });
}
function openRules(){openModal(`<h2>${t('rulesTitle')}</h2>${t('rulesBody',{t:V.pub?V.pub.tg:S.target})}`)}
function openProfile(){
  let sel=P.avatar,photo=P.photo;
  const draw=m=>{m.querySelectorAll('.avgrid button').forEach(b=>b.classList.toggle('on',!photo&&b.dataset.a===sel));m.querySelector('#pprev').innerHTML=avatarHTML(sel,photo);m.querySelector('#pprev').style.setProperty('--avbg',AVBG[sel]);m.querySelector('#rmPhoto').hidden=!photo};
  openModal(`<h2>${t('profile')}</h2>
    <div style="display:flex;gap:14px;align-items:center;margin-bottom:12px"><div class="avatar team0" id="pprev" style="--av:76px;flex:none"></div>
    <div style="flex:1"><label style="font-weight:700;font-size:14px" for="pname">${t('nickname')}</label><input class="field" id="pname" maxlength="16" placeholder="${esc(t('namePh'))}" value="${esc(P.name)}"></div></div>
    <b>${t('chooseAvatar')}</b>
    <div class="avgrid">${AVLIST().map(a=>`<button data-a="${a}" style="--avbg:${AVBG[a]}" aria-label="${a}">${avatarSVG(a)}</button>`).join('')}</div>
    <div class="mbtns"><label class="btn ghost" style="flex:1">${t('upload')}<input type="file" accept="image/*" id="pfile" hidden></label><button class="btn ghost" id="rmPhoto">${t('removePhoto')}</button></div>
    <div class="mbtns"><button class="btn yellow" id="psave">${t('save')}</button></div>${accountHTML()}`,m=>{
      draw(m);bindAccount(m);
      m.querySelectorAll('.avgrid button').forEach(b=>b.onclick=()=>{sel=b.dataset.a;photo=null;sfx('pop');draw(m)});
      m.querySelector('#pfile').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{photo=await readPhoto(f);draw(m)}catch(err){toast(t('photoErr'))}};
      m.querySelector('#rmPhoto').onclick=()=>{photo=null;draw(m)};
      m.querySelector('#psave').onclick=()=>{P.name=cleanName(m.querySelector('#pname').value);P.avatar=sel;P.photo=photo;saveP();renderChip();buildReactPanel();closeModal();sfx('click');netEmit('profile',prof())};
  });
}
function readPhoto(file){return new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>{const img=new Image();img.onload=()=>{const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');const s=Math.min(img.width,img.height);x.drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,128,128);res(c.toDataURL('image/jpeg',.82))};img.onerror=rej;img.src=fr.result};fr.onerror=rej;fr.readAsDataURL(file)})}
function openJoin(){
  openModal(`<h2>🔑 ${t('join')}</h2><p>${t('enterCode')}</p><input class="field" id="jcode" maxlength="5" autocomplete="off" autocapitalize="characters" style="text-transform:uppercase;letter-spacing:8px;text-align:center;font-size:30px"><div class="mbtns"><button class="btn yellow" id="jgo">${t('joinGo')}</button></div>`,m=>{
    const i=m.querySelector('#jcode');setTimeout(()=>i.focus(),50);
    const go=()=>{const c=i.value.toUpperCase().replace(/[^A-Z0-9]/g,'');if(c.length===5){closeModal();joinRoom(c)}else{i.animate([{translate:'-6px 0'},{translate:'6px 0'},{translate:'0'}],{duration:250})}};
    m.querySelector('#jgo').onclick=go;i.onkeydown=e=>{if(e.key==='Enter')go()};
  });
}
function renderChip(){$('#chipAv').innerHTML=avatarHTML(P.avatar,P.photo);$('#chipAv').style.setProperty('--avbg',AVBG[P.avatar]);$('#chipName').textContent=P.name||t('you')}
let wIdx=0;
function rotateWelcome(first){const w=t('welcome');const el=$('#welcome');if(first){wIdx=0;el.textContent=w[0];return}el.style.opacity=0;setTimeout(()=>{wIdx=(wIdx+1+rand(w.length-1))%w.length;el.textContent=w[wIdx];el.style.opacity=1},300)}
setInterval(()=>{if($('#home').classList.contains('active'))rotateWelcome()},4800);
function buildHomeArt(){
  const fan=$('#fan');['S','H','C','D'].forEach((s,i)=>{const c=cardEl({s,r:'A'});c.style.transform=`translateX(-50%) rotate(${-27+i*18}deg)`;fan.append(c)});
  const bg=$('#bgcards');for(let i=0;i<10;i++){const s=pick(SUITS),r=pick(RANKS);const c=i%3?cardEl({s,r}):Object.assign(document.createElement('div'),{className:'card back'});c.style.cssText=`--cw:${34+rand(26)}px;left:${rand(95)}%;animation-duration:${16+rand(14)}s;animation-delay:-${rand(20)}s`;bg.append(c)}
}
function applyLang(){
  document.documentElement.lang=S.lang==='si'?'si':'en';
  $$('[data-t]').forEach(e=>e.textContent=t(e.dataset.t));
  $$('#langsw button').forEach(b=>b.classList.toggle('on',b.dataset.lang===S.lang));
  rotateWelcome(true);renderChip();buildReactPanel();
  if(V.pub){if(V.pub.ph==='lobby')renderLobby(V.pub);else{V.seatSig=null;draw(V.pub,V.pub)}}
}
$$('#langsw button').forEach(b=>b.onclick=()=>{S.lang=b.dataset.lang;saveS();applyLang();sfx('click')});
$('#btnPlay').onclick=()=>{sfx('click');playNow()};
$('#btnRandom').onclick=()=>{sfx('click');quickMatch()};
$('#btnPrivate').onclick=()=>{sfx('click');createRoom()};
$('#btnJoin').onclick=()=>{sfx('click');openJoin()};
$('#btnBoard').onclick=()=>openStats();$('#btnSettings').onclick=openSettings;$('#btnRules').onclick=openRules;$('#profileChip').onclick=openProfile;
$('#hudSettings').onclick=openSettings;
$('#hudHome').onclick=()=>{const online=V.mode!=='off';openModal(`<h2>${online?t('leaveTitle'):t('quitTitle')}</h2><p>${online?t('leaveBody'):t('quitBody')}</p><div class="mbtns"><button class="btn coral" id="qy">${t('quitYes')}</button><button class="btn emerald" id="qn">${t('quitNo')}</button></div>`,m=>{m.querySelector('#qy').onclick=()=>{closeModal();goHome()};m.querySelector('#qn').onclick=closeModal})};

/* ================= LEADERBOARD (server) ================= */
Object.assign(T.si,{leaderboard:'ලීඩර්බෝඩ්',lbAll:'සේරම',lbWeek:'මේ සතිය',lbMonth:'මේ මාසෙ',lbEmpty:'තාම කවුරුත් නෑ. ගේමක් ගහලා ලිස්ට් එකේ උඩටම යන්න! 🚀',lbLoading:'ලීඩර්බෝඩ් එක load වෙනවා...',lbErr:'ලීඩර්බෝඩ් එකට සම්බන්ධ වෙන්න බැරි වුණා. ටිකකින් ආයෙත් බලන්න.',lbOff:'Shared ලීඩර්බෝඩ් එක පේන්නේ claude.ai එකට sign in වෙලා මේ artifact එක open කළාම විතරයි.',weekChamp:'මේ සතියේ චැම්පියන්',monthChamp:'මේ මාසේ චැම්පියන්',myStats:'මගේ ලකුණු',lbNoWrite:'ඔයාට තියෙන්නේ view-only access. ඔයාගේ ලකුණු ලීඩර්බෝඩ් එකට එකතු කරන්න owner ගෙන් Contributor access ඉල්ලන්න.',lbPublic:'ඔයාගේ නම, avatar එක, ලකුණු මේ artifact එක open කරන හැමෝටම පේනවා.',winsShort:'දිනුම්',gamesShort:'ගේම්'});
Object.assign(T.sl,{leaderboard:'Leaderboard',lbAll:'Serama',lbWeek:'Me sathiya',lbMonth:'Me maase',lbEmpty:'Thama kawruth nae. Game ekak gahala list eke udatama yanna! 🚀',lbLoading:'Leaderboard eka load wenawa...',lbErr:'Leaderboard ekata sambandha wenna bari wuna. Tikakin ayeth balanna.',lbOff:'Shared leaderboard eka penne claude.ai ekata sign in wela me artifact eka open kalama vitharai.',weekChamp:'Me sathiye champion',monthChamp:'Me maase champion',myStats:'Mage lakunu',lbNoWrite:'Oyata thiyenne view-only access. Oyage lakunu leaderboard ekata ekathu karanna owner gen Contributor access illanna.',lbPublic:'Oyage nama, avatar eka, lakunu me artifact eka open karana hamotama penawa.',winsShort:'Dinum',gamesShort:'Games'});
Object.assign(T.en,{leaderboard:'Leaderboard',lbAll:'All time',lbWeek:'This week',lbMonth:'This month',lbEmpty:'Nobody here yet. Play a game and grab the top spot! 🚀',lbLoading:'Loading the leaderboard...',lbErr:'Couldn’t reach the leaderboard. Check again in a moment.',lbOff:'The shared leaderboard appears when you open this artifact signed in to claude.ai.',weekChamp:'Champion of the week',monthChamp:'Champion of the month',myStats:'My stats',lbNoWrite:'You have view-only access, so your results aren’t added to the leaderboard. Ask the owner for Contributor access.',lbPublic:'Your nickname, avatar and stats are visible to everyone who opens this artifact.',winsShort:'Wins',gamesShort:'Games'});
const LB={tab:'all',open:false,rows:null,err:false,seq:0};
function periodKeys(){const d=new Date(Date.now()+5.5*3600e3);const y=d.getUTCFullYear(),mo=y+'-'+String(d.getUTCMonth()+1).padStart(2,'0');
  const t0=new Date(Date.UTC(y,d.getUTCMonth(),d.getUTCDate()));const day=(t0.getUTCDay()+6)%7;t0.setUTCDate(t0.getUTCDate()-day+3);
  const fy=t0.getUTCFullYear(),w=1+Math.round(((t0-Date.UTC(fy,0,4))/864e5-3+((new Date(Date.UTC(fy,0,4)).getUTCDay()+6)%7))/7);
  return{wk:fy+'-W'+String(w).padStart(2,'0'),mo}}
function rollPeriods(){const k=periodKeys();if(ST.wk!==k.wk){ST.wk=k.wk;ST.wkW=0;ST.wkP=0}if(ST.mo!==k.mo){ST.mo=k.mo;ST.moW=0;ST.moP=0}}
function loadLB(){LB.rows=null;LB.err=false;const n=++LB.seq;
  if(!NET.connected){LB.err=true;return}
  NET.sock.timeout(8000).emit('lb',{period:LB.tab},(err,r)=>{if(n!==LB.seq)return;if(err||!r||r.error)LB.err=true;else LB.rows=r.rows;if(LB.open)openStats(true)})}
function openStats(keep){
  if(!keep)loadLB();
  const pct=ST.played?Math.round(ST.wins/ST.played*100):0,got=awardIds(),AL=t('awardsList');
  let board=`<div class="seg lbtabs">${[['all',t('lbAll')],['week',t('lbWeek')],['month',t('lbMonth')]].map(([v,l])=>`<button data-tab="${v}" class="${LB.tab===v?'on':''}">${l}</button>`).join('')}</div>`;
  const rows=LB.rows||[];
  if(LB.err)board+=`<p class="note">${t('lbErr')}</p>`;
  else if(!LB.rows)board+=`<p class="note">${t('lbLoading')}</p>`;
  else if(!rows.length)board+=`<p class="note">${t('lbEmpty')}</p>`;
  else{
    if(LB.tab!=='all')board+=`<div class="champ"><span>👑</span><div><small>${t(LB.tab==='week'?'weekChamp':'monthChamp')}</small><b data-nm="0"></b></div></div>`;
    board+=`<div class="lbl">${rows.map((r,i)=>{const a=AV[r.avatar]?r.avatar:'cool';
      return `<div class="lbrow${r.me?' me':''}"><span class="rk">${['🥇','🥈','🥉'][i]||i+1}</span><div class="avs" style="--avbg:${AVBG[a]}">${avatarSVG(a)}</div><div class="nm"><b data-nm="${i}"></b><small>${esc(r.badges||'')}</small></div><div class="wn"><b>${r.w|0}</b><small>${t('winsShort')} · ${r.p|0} ${t('gamesShort')} · ${r.pct|0}%</small></div></div>`}).join('')}</div>`;
  }
  board+=`<p class="note">${t('lbPublic')}</p>`;
  const html=`<h2>🏆 ${t('leaderboard')}</h2>${board}
   <h3 style="margin:16px 0 8px">${t('myStats')}</h3>
   <div class="statgrid">${[['played',ST.played],['wins',ST.wins],['losses',ST.losses],['winPct',pct+'%'],['streak',ST.streak],['best',ST.best]].map(([k,v])=>`<div class="stat"><b>${v}</b><small>${t(k)}</small></div>`).join('')}</div>
   <h3 style="margin:4px 0 8px">${t('awards')}</h3>
   <div class="awards">${Object.keys(AL).map(k=>`<div class="award ${got.includes(k)?'':'locked'}"><div>${AL[k][0]}<small>${AL[k][1]}</small></div></div>`).join('')}</div>`;
  const sc=$('#modal').scrollTop;
  openModal(html,mm=>{
    mm.querySelectorAll('[data-nm]').forEach(el=>{const r=rows[+el.dataset.nm];if(r)el.textContent=cleanName(r.name)||'Player'});
    mm.querySelectorAll('.lbtabs button').forEach(b=>b.onclick=()=>{LB.tab=b.dataset.tab;sfx('click');loadLB();openStats(true)});
    mm.querySelector('.x').onclick=()=>{LB.open=false;closeModal()};
    if(keep)mm.scrollTop=sc;LB.open=true;
  });
}

/* ================= ACCOUNTS (Supabase Auth, optional) ================= */
const AUTH={sb:null};
async function initAuth(){
  try{const c=await (await fetch('/api/config')).json();if(!c.supabaseUrl||!c.supabaseAnonKey)return;
    await new Promise((res,rej)=>{const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js';s.onload=res;s.onerror=rej;document.head.append(s)});
    AUTH.sb=window.supabase.createClient(c.supabaseUrl,c.supabaseAnonKey);
    const {data}=await AUTH.sb.auth.getSession();const tok=data&&data.session?data.session.access_token:null;
    if(tok!==NET.token){NET.token=tok;connect()}
    AUTH.sb.auth.onAuthStateChange((ev,session)=>{const tk=session?session.access_token:null;if((ev==='SIGNED_IN'||ev==='SIGNED_OUT')&&tk!==NET.token){NET.token=tk;connect()}});
  }catch(e){console.warn('auth unavailable',e)}
}
function accountHTML(){
  if(!AUTH.sb)return'';
  if(NET.signedIn)return `<h3 style="margin:16px 0 6px">${t('account')}</h3><p class="note" id="acctEmail"></p><div class="mbtns"><button class="btn ghost" id="signOut">${t('signOut')}</button></div>`;
  return `<h3 style="margin:16px 0 6px">${t('account')}</h3><p class="note">${t('guestNote')}</p><div class="mbtns"><button class="btn navy" id="gIn">${t('signInGoogle')}</button></div>
    <div class="mbtns"><input class="field" id="emailIn" type="email" autocomplete="email" placeholder="${esc(t('emailPh'))}" style="flex:2;min-width:180px"><button class="btn ghost" id="mailIn">${t('sendLink')}</button></div>`;
}
function bindAccount(m){
  if(!AUTH.sb)return;const e=m.querySelector('#acctEmail');if(e)e.textContent=t('signedInAs',{e:NET.email||''});
  const so=m.querySelector('#signOut');if(so)so.onclick=async()=>{await AUTH.sb.auth.signOut();closeModal()};
  const g=m.querySelector('#gIn');if(g)g.onclick=()=>AUTH.sb.auth.signInWithOAuth({provider:'google',options:{redirectTo:location.origin+'/'}});
  const mi=m.querySelector('#mailIn');if(mi)mi.onclick=async()=>{const v=m.querySelector('#emailIn').value.trim();if(!/^\S+@\S+\.\S+$/.test(v))return;
    const {error}=await AUTH.sb.auth.signInWithOtp({email:v,options:{emailRedirectTo:location.origin+'/'}});toast(error?t('roomErr'):t('linkSent'))};
}
/* ================= CONFETTI ================= */
function confetti(){
  const c=$('#confetti'),x=c.getContext('2d'),dpr=Math.min(2,window.devicePixelRatio||1);c.width=innerWidth*dpr;c.height=innerHeight*dpr;x.setTransform(dpr,0,0,dpr,0,0);
  const cols=['#ffd23f','#ff8c42','#ff5a5f','#12b886','#ffffff','#5b8cff'],ps=[];
  for(let i=0;i<180;i++)ps.push({x:innerWidth/2+(Math.random()-.5)*innerWidth*.4,y:innerHeight*.35,vx:(Math.random()-.5)*15,vy:-Math.random()*15-4,r:Math.random()*6.3,vr:(Math.random()-.5)*.4,w:6+Math.random()*7,h:4+Math.random()*6,c:pick(cols)});
  const t0=performance.now();
  (function f(now){const el=now-t0;x.clearRect(0,0,innerWidth,innerHeight);
    ps.forEach(p=>{p.vy+=.32;p.vx*=.99;p.x+=p.vx;p.y+=p.vy;p.r+=p.vr;x.save();x.translate(p.x,p.y);x.rotate(p.r);x.fillStyle=p.c;x.globalAlpha=Math.max(0,1-el/4200);x.fillRect(-p.w/2,-p.h/2,p.w,p.h);x.restore()});
    if(el<4200)requestAnimationFrame(f);else x.clearRect(0,0,innerWidth,innerHeight)})(t0);
}

/* ================= BOOT ================= */
buildHomeArt();applyLang();
document.addEventListener('pointerdown',()=>actx(),{once:true});
{const q=(new URLSearchParams(location.search).get('room')||location.hash.slice(1)||'').toUpperCase();if(/^[A-Z0-9]{5}$/.test(q)){NET.pendingJoin=q;resetView('net');showScreen('lobby');$('#lbCode').textContent=q;$('#lbStatus').textContent=t('connecting');$('#lbStart').hidden=true}}
connect();initAuth();
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
setTimeout(()=>{if(NET.pendingJoin&&!NET.connected){NET.pendingJoin=null;toast(t('serverDown'));goHome()}},10000);
})();
