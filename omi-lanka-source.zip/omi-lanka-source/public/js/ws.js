// Tiny WebSocket client exposing the small part of the Socket.IO API that OMI LANKA uses.
(()=>{
function io(opts){
  const auth=(opts&&opts.auth)||{},maxDelay=(opts&&opts.reconnectionDelayMax)||4000;
  const L={},acks=new Map();let ws=null,ackN=0,closedByUser=false,tries=0,timer=null;
  const s={connected:false,
    on(ev,fn){(L[ev]=L[ev]||[]).push(fn);return s},
    removeAllListeners(){for(const k in L)delete L[k];return s},
    emit(ev,data,cb){if(!s.connected||!ws)return s;const m={e:ev,d:data};if(typeof cb==='function'){const a=++ackN;m.a=a;acks.set(a,{cb})}ws.send(JSON.stringify(m));return s},
    timeout(ms){return{emit(ev,data,cb){if(!s.connected){setTimeout(()=>cb(new Error('offline')),0);return}let done=false;
      const t=setTimeout(()=>{if(!done){done=true;cb(new Error('timeout'))}},ms);
      s.emit(ev,data,res=>{if(!done){done=true;clearTimeout(t);cb(null,res)}})}}},
    disconnect(){closedByUser=true;clearTimeout(timer);if(ws)try{ws.close(1000)}catch(e){}return s}};
  const fire=(ev,...a)=>(L[ev]||[]).slice().forEach(f=>{try{f(...a)}catch(e){console.error(e)}});
  function open(){
    const url=(location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws';
    try{ws=new WebSocket(url)}catch(e){return retry()}
    ws.onopen=()=>ws.send(JSON.stringify({e:'auth',d:{cid:auth.cid,token:auth.token||null}}));
    ws.onmessage=ev=>{let m;try{m=JSON.parse(ev.data)}catch(e){return}
      if(m.ack){const a=acks.get(m.ack);if(a){acks.delete(m.ack);a.cb(m.d)}return}
      if(m.e==='hello'){tries=0;s.connected=true;fire('connect');fire('hello',m.d);return}
      if(m.e==='connect_error'){fire('connect_error',new Error(m.d||'error'));if(m.d==='banned')closedByUser=true;return}
      fire(m.e,m.d)};
    ws.onclose=()=>{const was=s.connected;s.connected=false;acks.clear();if(was)fire('disconnect');if(!closedByUser)retry()};
    ws.onerror=()=>{if(!s.connected)fire('connect_error',new Error('unreachable'))};
  }
  function retry(){clearTimeout(timer);tries++;timer=setTimeout(open,Math.min(maxDelay,300*2**tries)+Math.random()*300)}
  open();return s;
}
window.io=io;
})();
