(()=>{
const $=s=>document.querySelector(s);let TOK=sessionStorage.getItem('omiAdmin')||'';
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(path,body){const r=await fetch('/api/admin/'+path,{method:body?'POST':'GET',headers:{'x-admin-token':TOK,'content-type':'application/json'},body:body?JSON.stringify(body):undefined});if(r.status===403)throw new Error('forbidden');return r.json()}
function table(cols,rows){return `<div style="overflow-x:auto"><table><tr>${cols.map(c=>`<th>${c[0]}</th>`).join('')}</tr>${rows.map(r=>`<tr>${cols.map(c=>`<td>${c[1](r)}</td>`).join('')}</tr>`).join('')||`<tr><td colspan="${cols.length}">None</td></tr>`}</table></div>`}
async function load(){
  let d;try{d=await api('overview?q='+encodeURIComponent($('#q').value||''))}catch(e){$('#login').hidden=false;$('#dash').hidden=true;alert('Wrong admin token');return}
  $('#login').hidden=true;$('#dash').hidden=false;
  $('#kpi').innerHTML=`<span class="k">🟢 Online now: ${d.online}</span><span class="k">🎴 Active rooms: ${d.rooms.length}</span><span class="k">👥 Players: ${d.total}</span><span class="k">💾 Store: ${esc(d.store)}</span>`;
  $('#rooms').innerHTML=table([['Code',r=>`<b>${esc(r.code)}</b>`],['Phase',r=>esc(r.ph)],['Players',r=>r.players.map(p=>!p?'—':p.bot?'🤖':`${p.online?'🟢':'⚪'} ${esc(p.name)}`).join(', ')],['Score',r=>r.score.join(' – ')],['Round',r=>r.round],['Type',r=>r.pub?'public':'private'],['',r=>`<button class="red" data-close="${esc(r.code)}">Close</button>`]],d.rooms);
  $('#reports').innerHTML=table([['When',r=>esc((r.created_at||r.at||'').slice(0,16))],['Reported',r=>`${esc(r.target_name)} <code>${esc(r.target)}</code>`],['Room',r=>esc(r.room)],['',r=>`<button class="red" data-ban="${esc(r.target)}">Ban</button>`]],d.reports);
  $('#players').innerHTML=table([['Name',r=>esc(r.name||'Player')],['ID',r=>`<code>${esc(r.id)}</code>`],['Played',r=>r.played],['Wins',r=>r.wins],['',r=>`<button data-rename="${esc(r.id)}">Rename</button> <button class="red" data-ban="${esc(r.id)}">Ban</button>`]],d.players);
  $('#banned').innerHTML=table([['ID',r=>`<code>${esc(r.id)}</code>`],['Reason',r=>esc(r.reason)],['',r=>`<button data-unban="${esc(r.id)}">Unban</button>`]],d.banned);
}
document.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;
  if(b.id==='go'){TOK=$('#tok').value;sessionStorage.setItem('omiAdmin',TOK);load()}
  else if(b.id==='search')load();
  else if(b.dataset.close&&confirm('Close room '+b.dataset.close+'?')){await api('close-room',{code:b.dataset.close});load()}
  else if(b.dataset.ban){const reason=prompt('Reason for ban?');if(reason!==null){await api('ban',{id:b.dataset.ban,reason});load()}}
  else if(b.dataset.unban){await api('unban',{id:b.dataset.unban});load()}
  else if(b.dataset.rename){const n=prompt('New nickname (max 16 characters)');if(n){await api('rename',{id:b.dataset.rename,name:n});load()}}
});
if(TOK)load();setInterval(()=>{if(!$('#dash').hidden)load()},15000);
})();
