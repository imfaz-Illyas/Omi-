// OMI LANKA on Cloudflare: a Worker serves the website, and one Durable Object ("GameHub")
// runs every live game (server-authoritative), the WebSocket connections and the stats database.
import {DurableObject} from 'cloudflare:workers';
import {AVATARS,REACTS} from './engine.js';
import {Rooms} from './rooms.js';
import {SqlStore} from './store.js';
import {FILES} from './assets.js';

const cleanName=n=>String(n||'').replace(/[\u0000-\u001f\u007f\u200b\u200e\u200f\u202a-\u202e\u2060-\u2064\ufeff<>]/g,'').trim().slice(0,16);
const cleanSettings=x=>{x=x||{};return{target:[5,10,15].includes(+x.target)?+x.target:10,kapothi:['3','game','none'].includes(x.kapothi)?x.kapothi:'3',timer:x.timer!==false,speed:['slow','normal','fast'].includes(x.speed)?x.speed:'normal'}};
const json=(d,status=200)=>new Response(JSON.stringify(d),{status,headers:{'content-type':'application/json'}});
const siteUrl=(env,url)=>(env.SITE_URL||url.origin).replace(/\/$/,'');

function secure(res,url){
  const r=new Response(res.body,res);const host=url.host;
  r.headers.set('X-Content-Type-Options','nosniff');r.headers.set('Referrer-Policy','strict-origin-when-cross-origin');r.headers.set('X-Frame-Options','SAMEORIGIN');
  r.headers.set('Permissions-Policy','camera=(), microphone=(), geolocation=()');
  r.headers.set('Content-Security-Policy',[`default-src 'self'`,`script-src 'self' https://cdn.jsdelivr.net`,`style-src 'self' 'unsafe-inline' https://fonts.googleapis.com`,`font-src 'self' https://fonts.gstatic.com`,
    `img-src 'self' data: blob: https:`,`connect-src 'self' wss://${host} ws://${host} https://*.supabase.co wss://*.supabase.co`,`frame-ancestors 'self'`,`base-uri 'self'`,`form-action 'self'`].join('; '));
  return r;
}
function sitemap(u){const d=new Date().toISOString().slice(0,10);const alt=`<xhtml:link rel="alternate" hreflang="si" href="${u}/how-to-play/"/><xhtml:link rel="alternate" hreflang="en" href="${u}/en/how-to-play/"/>`;
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n  <url><loc>${u}/</loc><lastmod>${d}</lastmod><priority>1.0</priority></url>\n  <url><loc>${u}/how-to-play/</loc><lastmod>${d}</lastmod><priority>0.8</priority>${alt}</url>\n  <url><loc>${u}/en/how-to-play/</loc><lastmod>${d}</lastmod><priority>0.8</priority>${alt}</url>\n</urlset>\n`}


const BIN=new Map();
function serveFile(p){
  if(p==='/how-to-play'||p==='/en/how-to-play')return new Response(null,{status:301,headers:{location:p+'/'}});
  let k=p==='/'?'/index.html':p.endsWith('/')?p+'index.html':p==='/admin'?'/admin.html':p;
  const f=FILES[k];if(!f)return new Response('',{status:404});
  let body=f.s;
  if(f.b){body=BIN.get(k);if(!body){const s=atob(f.b);body=new Uint8Array(s.length);for(let i=0;i<s.length;i++)body[i]=s.charCodeAt(i);BIN.set(k,body)}}
  const cc=/\/(sw\.js|manifest\.webmanifest)$/.test(k)?'no-cache':'public, max-age=86400';
  return new Response(body,{headers:{'content-type':f.t,'cache-control':cc}});
}

export default {
  async fetch(req,env){
    const url=new URL(req.url),p=url.pathname;
    if(p==='/ws'||p==='/healthz'||p.startsWith('/api/admin'))return env.GAME.get(env.GAME.idFromName('main')).fetch(req);
    if(p==='/robots.txt')return secure(new Response(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\n\nSitemap: ${siteUrl(env,url)}/sitemap.xml\n`,{headers:{'content-type':'text/plain; charset=utf-8'}}),url);
    if(p==='/sitemap.xml')return secure(new Response(sitemap(siteUrl(env,url)),{headers:{'content-type':'application/xml'}}),url);
    if(p==='/api/config')return secure(json({supabaseUrl:env.SUPABASE_URL||null,supabaseAnonKey:env.SUPABASE_ANON_KEY||null}),url);
    let res=serveFile(p);
    if(res.status===404)return secure(new Response('<!doctype html><meta charset="utf-8"><title>404 – OMI LANKA</title><p style="font-family:sans-serif;padding:24px">404 – <a href="/">OMI LANKA 🃏</a></p>',{status:404,headers:{'content-type':'text/html; charset=utf-8'}}),url);
    if((res.headers.get('content-type')||'').includes('text/html')){
      const html=(await res.text()).replace(/%%SITE_URL%%/g,siteUrl(env,url));
      res=new Response(html,{status:res.status,headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-cache'}});
    }
    return secure(res,url);
  }
};

/* ---- a WebSocket connection made to look like the Socket.IO socket the room code expects ---- */
class Sock{
  constructor(hub,ws){this.hub=hub;this.ws=ws;this.data=null;this.h={};this.codes=new Set();this.open=true}
  emit(ev,d){if(!this.open)return;try{this.ws.send(JSON.stringify({e:ev,d}))}catch(e){}}
  on(ev,fn){this.h[ev]=fn}
  join(code){this.codes.add(code);let s=this.hub.groups.get(code);if(!s)this.hub.groups.set(code,s=new Set());s.add(this)}
  leave(code){this.codes.delete(code);const s=this.hub.groups.get(code);if(s){s.delete(this);if(!s.size)this.hub.groups.delete(code)}}
  to(code){return{emit:(ev,d)=>{for(const s of this.hub.groups.get(code)||[])if(s!==this)s.emit(ev,d)}}}
  disconnect(){try{this.ws.close(4003,'closed')}catch(e){}this.hub.closed(this)}
}

export class GameHub extends DurableObject{
  constructor(ctx,env){
    super(ctx,env);this.env=env;
    globalThis.__OMI_TIME_SCALE=+env.GAME_TIME_SCALE||1;
    this.store=new SqlStore(ctx.storage.sql);
    this.rooms=new Rooms(this.store,{countBotGames:env.COUNT_BOT_GAMES!=='false',maxRooms:+env.MAX_ROOMS||3000});
    this.socks=new Set();this.groups=new Map();
  }
  adminOk(req){const t=this.env.ADMIN_TOKEN||'',g=req.headers.get('x-admin-token')||'';if(t.length<12||g.length!==t.length)return false;let d=0;for(let i=0;i<t.length;i++)d|=t.charCodeAt(i)^g.charCodeAt(i);return d===0}
  async fetch(req){
    const url=new URL(req.url),p=url.pathname;
    if(p==='/healthz')return json({ok:true,rooms:this.rooms.map.size,online:this.socks.size,store:this.store.kind});
    if(p.startsWith('/api/admin'))return secure(await this.admin(req,url),url);
    if(p==='/ws'){
      if(req.headers.get('Upgrade')!=='websocket')return new Response('Expected WebSocket',{status:426});
      const origin=req.headers.get('Origin');if(origin&&new URL(origin).host!==url.host)return new Response('Bad origin',{status:403});
      const pair=new WebSocketPair(),[client,server]=Object.values(pair);server.accept();this.attach(server);
      return new Response(null,{status:101,webSocket:client});
    }
    return new Response('Not found',{status:404});
  }
  async admin(req,url){
    if(!this.adminOk(req))return json({error:'forbidden'},403);
    const p=url.pathname.replace('/api/admin/',''),body=req.method==='POST'?await req.json().catch(()=>({})):{};
    if(p==='overview'){const d=await this.store.adminData(String(url.searchParams.get('q')||'').slice(0,40));return json(Object.assign(d,{online:this.socks.size,store:this.store.kind,rooms:[...this.rooms.map.values()].map(r=>r.summary())}))}
    if(p==='close-room'){this.rooms.close(String(body.code||''));return json({ok:true})}
    if(p==='ban'){const id=String(body.id||'');if(!id)return json({error:'id'},400);await this.store.ban(id,String(body.reason||'').slice(0,200));for(const s of [...this.socks])if(s.data&&s.data.id===id)s.disconnect();return json({ok:true})}
    if(p==='unban'){await this.store.unban(String(body.id||''));return json({ok:true})}
    if(p==='rename'){await this.store.rename(String(body.id||''),cleanName(body.name)||'Player');return json({ok:true})}
    return json({error:'not found'},404);
  }
  closed(sk){if(!sk.open)return;sk.open=false;this.socks.delete(sk);if(sk.h.disconnect)sk.h.disconnect();for(const c of [...sk.codes])sk.leave(c)}
  attach(ws){
    const sk=new Sock(this,ws);this.socks.add(sk);
    const authT=setTimeout(()=>{if(!sk.data)sk.disconnect()},10000);
    ws.addEventListener('message',async ev=>{
      let m;try{m=JSON.parse(typeof ev.data==='string'?ev.data:'');}catch(e){return}if(!m||typeof m.e!=='string'||String(ev.data).length>10000)return;
      if(!sk.data){if(m.e==='auth'){clearTimeout(authT);await this.auth(sk,m.d||{})}return}
      const fn=sk.h[m.e];if(!fn)return;
      const ack=typeof m.a==='number'?res=>{try{sk.ws.send(JSON.stringify({ack:m.a,d:res}))}catch(e){}}:undefined;
      try{await fn(m.d,ack)}catch(e){console.error('handler',m.e,e)}
    });
    ws.addEventListener('close',()=>{clearTimeout(authT);this.closed(sk)});
    ws.addEventListener('error',()=>this.closed(sk));
  }
  async auth(sk,a){
    const cid=typeof a.cid==='string'&&/^[a-z0-9]{8,40}$/i.test(a.cid)?a.cid:null;
    if(!cid){sk.emit('connect_error','bad_client');return sk.disconnect()}
    let uid=null,email=null;const env=this.env;
    if(a.token&&env.SUPABASE_URL&&env.SUPABASE_ANON_KEY){
      try{const r=await fetch(env.SUPABASE_URL.replace(/\/$/,'')+'/auth/v1/user',{headers:{apikey:env.SUPABASE_ANON_KEY,Authorization:'Bearer '+String(a.token)}});
        if(r.ok){const u=await r.json();if(u&&u.id){uid=u.id;email=u.email||null}}}catch(e){}
    }
    const id=uid?'u:'+uid:'g:'+cid;
    if(await this.store.isBanned(id)){sk.emit('connect_error','banned');return sk.disconnect()}
    sk.data={id,uid,email,name:'',avatar:'cool',room:null,bucket:30,ts:Date.now()};
    if(uid)await this.store.mergeGuest('g:'+cid,id);
    this.wire(sk);sk.emit('hello',{signedIn:!!uid,email});
  }
  wire(sk){
    const rooms=this.rooms,store=this.store;
    const ok=()=>{const d=sk.data,now=Date.now();d.bucket=Math.min(30,d.bucket+(now-d.ts)/100);d.ts=now;if(d.bucket<1)return false;d.bucket--;return true};
    const prof=p=>{p=p||{};sk.data.name=cleanName(p.name);sk.data.avatar=AVATARS.includes(p.avatar)?p.avatar:'cool'};
    const leaveCur=explicit=>{const r=sk.data.room;if(r){r.leave(sk,explicit);sk.leave(r.code);sk.data.room=null}};
    const cb=f=>typeof f==='function'?f:()=>{};
    sk.on('create',(p,f)=>{if(!ok())return;prof(p);leaveCur(true);try{const r=rooms.create({pub:false,settings:cleanSettings(p&&p.settings)});r.join(sk);if(p&&p.solo)r.H.start();cb(f)({code:r.code})}catch(e){cb(f)({error:'full'})}});
    sk.on('quick',(p,f)=>{if(!ok())return;prof(p);leaveCur(true);try{const r=rooms.quick(cleanSettings(p&&p.settings));r.join(sk);cb(f)({code:r.code})}catch(e){cb(f)({error:'full'})}});
    sk.on('join',(p,f)=>{if(!ok())return;prof(p);const r=rooms.get(String(p&&p.code||'').toUpperCase());if(!r)return cb(f)({error:'noRoom'});if(sk.data.room!==r)leaveCur(true);r.join(sk);cb(f)({code:r.code})});
    sk.on('leave',()=>leaveCur(true));
    sk.on('sit',p=>{const r=sk.data.room;if(r&&ok())r.sit(sk,p&&+p.s)});
    sk.on('start',()=>{const r=sk.data.room;if(r&&r.isHost(sk)&&r.H.s.ph==='lobby')r.H.start()});
    sk.on('rematch',()=>{const r=sk.data.room;if(r&&r.isHost(sk)&&r.H.s.ph==='end')r.H.run()});
    sk.on('cont',()=>{const r=sk.data.room;if(r&&r.isHost(sk))r.H.cont()});
    sk.on('act',p=>{const r=sk.data.room;if(!r||!ok()||!p)return;const seat=r.seatOf(sk);if(seat>=0&&typeof p.val==='string')r.H.input(seat,String(p.kind),p.val)});
    sk.on('rx',p=>{const r=sk.data.room;if(!r||!p||!REACTS.includes(p.e))return;const seat=r.seatOf(sk);if(seat<0||Date.now()-r.lastRx[seat]<800)return;r.lastRx[seat]=Date.now();sk.to(r.code).emit('rx',{seat,e:p.e});r.H.humanRx(seat,p.e)});
    sk.on('profile',p=>{if(!ok())return;prof(p);store.setProfile(sk.data.id,sk.data.name,sk.data.avatar).catch(()=>{});const r=sk.data.room;if(r)r.setProfile(sk)});
    sk.on('report',(p,f)=>{const r=sk.data.room;if(!r||!ok())return;const seat=+(p&&p.seat);const target=r.ids[seat];if(!target||target===sk.data.id)return;const st=r.H.s.seats[seat]||{};
      store.report({reporter:sk.data.id,target,target_name:st.n||'',room:r.code,reason:String(p.reason||'').slice(0,200)}).catch(()=>{});cb(f)({ok:true})});
    sk.on('lb',async(p,f)=>{if(!ok())return;try{cb(f)({rows:await store.leaderboard(['week','month'].includes(p&&p.period)?p.period:'all',sk.data.id)})}catch(e){cb(f)({error:true})}});
    sk.on('disconnect',()=>leaveCur(false));
  }
}
