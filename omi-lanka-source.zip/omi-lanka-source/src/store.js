// Player stats storage inside the Durable Object's built-in SQLite database.
function periodKeys(){ // weeks/months in Sri Lanka time (UTC+5:30)
  const d=new Date(Date.now()+5.5*3600e3);const y=d.getUTCFullYear(),mo=y+'-'+String(d.getUTCMonth()+1).padStart(2,'0');
  const t0=new Date(Date.UTC(y,d.getUTCMonth(),d.getUTCDate()));const day=(t0.getUTCDay()+6)%7;t0.setUTCDate(t0.getUTCDate()-day+3);
  const fy=t0.getUTCFullYear(),w=1+Math.round(((t0-Date.UTC(fy,0,4))/864e5-3+((new Date(Date.UTC(fy,0,4)).getUTCDay()+6)%7))/7);
  return{wk:fy+'-W'+String(w).padStart(2,'0'),mo};
}
const blank=id=>({id,name:'',avatar:'cool',played:0,wins:0,losses:0,streak:0,best:0,kapothis:0,comebacks:0,whitewash:0,wk:null,wk_wins:0,wk_played:0,mo:null,mo_wins:0,mo_played:0});
function apply(r,info){
  const k=periodKeys();
  if(r.wk!==k.wk){r.wk=k.wk;r.wk_wins=0;r.wk_played=0}
  if(r.mo!==k.mo){r.mo=k.mo;r.mo_wins=0;r.mo_played=0}
  if(info.name)r.name=info.name;if(info.avatar)r.avatar=info.avatar;
  r.played++;r.wk_played++;r.mo_played++;
  if(info.win){r.wins++;r.wk_wins++;r.mo_wins++;r.streak++;r.best=Math.max(r.best,r.streak);if(info.comeback)r.comebacks++}
  else{r.losses++;r.streak=0;if(info.whitewash)r.whitewash++}
  r.kapothis+=info.kap|0;r.updated_at=new Date().toISOString();return r;
}
function badges(r){const e=[];if(r.wins>=10)e.push('👑');if(r.losses>=5)e.push('😂');if(r.comebacks>=1)e.push('🔥');if(r.whitewash>=1)e.push('💀');if(r.kapothis>=1)e.push('🎯');if(r.played>=50)e.push('🃏');return e.join('')}
function rows(list,period,meId){
  const k=periodKeys();
  const out=list.map(r=>{const w=period==='week'?(r.wk===k.wk?r.wk_wins:0):period==='month'?(r.mo===k.mo?r.mo_wins:0):r.wins;
    const p=period==='week'?(r.wk===k.wk?r.wk_played:0):period==='month'?(r.mo===k.mo?r.mo_played:0):r.played;
    return{name:r.name||'Player',avatar:r.avatar,w,p,pct:p?Math.round(w/p*100):0,badges:badges(r),me:r.id===meId}}).filter(x=>x.p>0);
  out.sort((a,b)=>b.w-a.w||b.pct-a.pct||a.p-b.p);return out.slice(0,50);
}


const COLS=['id','name','avatar','played','wins','losses','streak','best','kapothis','comebacks','whitewash','wk','wk_wins','wk_played','mo','mo_wins','mo_played','updated_at'];
export class SqlStore{
  constructor(sql){
    this.sql=sql;this.kind='durable-object-sqlite';
    sql.exec(`CREATE TABLE IF NOT EXISTS players(id TEXT PRIMARY KEY,name TEXT NOT NULL DEFAULT '',avatar TEXT NOT NULL DEFAULT 'cool',played INTEGER NOT NULL DEFAULT 0,wins INTEGER NOT NULL DEFAULT 0,losses INTEGER NOT NULL DEFAULT 0,streak INTEGER NOT NULL DEFAULT 0,best INTEGER NOT NULL DEFAULT 0,kapothis INTEGER NOT NULL DEFAULT 0,comebacks INTEGER NOT NULL DEFAULT 0,whitewash INTEGER NOT NULL DEFAULT 0,wk TEXT,wk_wins INTEGER NOT NULL DEFAULT 0,wk_played INTEGER NOT NULL DEFAULT 0,mo TEXT,mo_wins INTEGER NOT NULL DEFAULT 0,mo_played INTEGER NOT NULL DEFAULT 0,updated_at TEXT)`);
    sql.exec(`CREATE INDEX IF NOT EXISTS players_wins ON players(wins DESC)`);
    sql.exec(`CREATE INDEX IF NOT EXISTS players_wk ON players(wk, wk_wins DESC)`);
    sql.exec(`CREATE INDEX IF NOT EXISTS players_mo ON players(mo, mo_wins DESC)`);
    sql.exec(`CREATE TABLE IF NOT EXISTS banned(id TEXT PRIMARY KEY,reason TEXT NOT NULL DEFAULT '',created_at TEXT)`);
    sql.exec(`CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY AUTOINCREMENT,reporter TEXT,target TEXT,target_name TEXT,room TEXT,reason TEXT,created_at TEXT)`);
  }
  all(q,...p){return this.sql.exec(q,...p).toArray()}
  one(q,...p){return this.all(q,...p)[0]||null}
  async record(id,info){const r=apply(this.one('SELECT * FROM players WHERE id=?',id)||blank(id),info);
    this.sql.exec(`INSERT OR REPLACE INTO players(${COLS.join(',')}) VALUES(${COLS.map(()=>'?').join(',')})`,...COLS.map(c=>r[c]===undefined?null:r[c]))}
  async leaderboard(period,meId){const k=periodKeys();let list;
    if(period==='week')list=this.all('SELECT * FROM players WHERE wk=? AND wk_played>0 ORDER BY wk_wins DESC LIMIT 200',k.wk);
    else if(period==='month')list=this.all('SELECT * FROM players WHERE mo=? AND mo_played>0 ORDER BY mo_wins DESC LIMIT 200',k.mo);
    else list=this.all('SELECT * FROM players WHERE played>0 ORDER BY wins DESC LIMIT 200');
    return rows(list,period,meId)}
  async setProfile(id,name,avatar){if(name)this.sql.exec('UPDATE players SET name=?,avatar=? WHERE id=?',name,avatar,id);else this.sql.exec('UPDATE players SET avatar=? WHERE id=?',avatar,id)}
  async mergeGuest(from,to){if(this.one('SELECT id FROM players WHERE id=?',to)||!this.one('SELECT id FROM players WHERE id=?',from))return;this.sql.exec('UPDATE players SET id=? WHERE id=?',to,from)}
  async isBanned(id){return !!this.one('SELECT id FROM banned WHERE id=?',id)}
  async ban(id,reason){this.sql.exec('INSERT OR REPLACE INTO banned(id,reason,created_at) VALUES(?,?,?)',id,reason||'',new Date().toISOString())}
  async unban(id){this.sql.exec('DELETE FROM banned WHERE id=?',id)}
  async rename(id,name){this.sql.exec('UPDATE players SET name=? WHERE id=?',name,id)}
  async report(x){this.sql.exec('INSERT INTO reports(reporter,target,target_name,room,reason,created_at) VALUES(?,?,?,?,?,?)',x.reporter,x.target,x.target_name||'',x.room||'',x.reason||'',new Date().toISOString());
    this.sql.exec('DELETE FROM reports WHERE id NOT IN (SELECT id FROM reports ORDER BY id DESC LIMIT 1000)')}
  async adminData(q){
    const players=q?this.all("SELECT * FROM players WHERE lower(name) LIKE ? ORDER BY played DESC LIMIT 100",'%'+q.toLowerCase().replace(/[%_]/g,'')+'%'):this.all('SELECT * FROM players ORDER BY played DESC LIMIT 100');
    return{total:this.one('SELECT COUNT(*) AS n FROM players').n,players,banned:this.all('SELECT * FROM banned ORDER BY created_at DESC LIMIT 200'),reports:this.all('SELECT * FROM reports ORDER BY id DESC LIMIT 100')}}
}
