'use strict';
import {createHost,rand} from './engine.js';
const ALPH='ABCDEFGHJKMNPQRSTUVWXYZ23456789';

class Room{
  constructor(mgr,code,{pub,settings}){
    this.mgr=mgr;this.code=code;this.pub=!!pub;this.ids=[null,null,null,null];this.sock=[null,null,null,null];this.spect=new Set();
    this.hostId=null;this.created=Date.now();this.emptySince=0;this.track={maxDef:[0,0],kap:[0,0],rbN:0,endN:0};this.lastRx=[0,0,0,0];
    this.H=createHost(settings,{seats:[null,null,null,null],lobby:true,pubTbl:this.pub,onPub:()=>this.broadcast()});
  }
  seatOf(sk){return this.sock.indexOf(sk)}
  isHost(sk){const s=this.seatOf(sk);return s>=0&&this.ids[s]===this.hostId}
  join(sk){
    const id=sk.data.id,s=this.H.s;let seat=this.ids.indexOf(id);
    if(seat<0&&s.ph==='lobby'){const free=[0,2,1,3].find(i=>!s.seats[i]);if(free!==undefined){seat=free;this.ids[seat]=id;s.seats[seat]={h:1,on:1};if(!this.hostId)this.hostId=id}}
    if(seat>=0){const old=this.sock[seat];if(old&&old!==sk){old.leave(this.code);old.data.room=null;old.emit('closed',{reason:'elsewhere'})}
      this.sock[seat]=sk;const st=s.seats[seat];st.on=1;st.n=sk.data.name;st.a=sk.data.avatar;}
    else this.spect.add(sk);
    sk.join(this.code);sk.data.room=this;this.emptySince=0;this.H.pub();
  }
  leave(sk,explicit){
    this.spect.delete(sk);const seat=this.seatOf(sk);if(seat<0){if(!this.connected())this.emptySince=Date.now();return}this.sock[seat]=null;const s=this.H.s;
    if(s.ph==='lobby'){
      s.seats[seat]=null;const id=this.ids[seat];this.ids[seat]=null;
      if(seat===0){const other=[2,1,3].find(i=>this.sock[i]);if(other!==undefined){s.seats[0]=s.seats[other];s.seats[other]=null;this.ids[0]=this.ids[other];this.ids[other]=null;this.sock[0]=this.sock[other];this.sock[other]=null}}
      if(id===this.hostId)this.hostId=this.ids.find((x,i)=>x&&this.sock[i])||null;
    }else{
      s.seats[seat].on=0;this.H.offAt[seat]=Date.now();
      if(this.ids[seat]===this.hostId){const i=this.ids.findIndex((x,j)=>x&&this.sock[j]);if(i>=0)this.hostId=this.ids[i]}
    }
    if(!this.connected())this.emptySince=Date.now();
    this.H.pub();
  }
  sit(sk,to){const s=this.H.s,seat=this.seatOf(sk);if(s.ph!=='lobby'||seat<1||![1,2,3].includes(to)||s.seats[to])return;
    s.seats[to]=s.seats[seat];s.seats[seat]=null;this.ids[to]=this.ids[seat];this.ids[seat]=null;this.sock[to]=sk;this.sock[seat]=null;this.H.pub()}
  setProfile(sk){const seat=this.seatOf(sk);if(seat<0)return;const st=this.H.s.seats[seat];if(st&&st.h){st.n=sk.data.name;st.a=sk.data.avatar;this.H.pub()}}
  connected(){return this.sock.some(Boolean)||this.spect.size>0}
  broadcast(){
    const H=this.H,g=H.view();
    if(g.rb&&g.rb.n!==this.track.rbN){this.track.rbN=g.rb.n;if(g.rb.kap&&!g.rb.tie)this.track.kap[g.rb.wt]++}
    for(const t of [0,1])this.track.maxDef[t]=Math.max(this.track.maxDef[t],g.sc[1-t]-g.sc[t]);
    if(g.ph==='end'&&g.end&&g.end.n!==this.track.endN){this.track.endN=g.end.n;this.recordEnd(g);this.track.maxDef=[0,0];this.track.kap=[0,0]}
    for(let i=0;i<4;i++){const sk=this.sock[i];if(sk)sk.emit('state',{g,hand:H.hands[i].map(c=>c.id),you:i,code:this.code,host:this.ids[i]===this.hostId,pub:this.pub})}
    for(const sk of this.spect)sk.emit('state',{g,hand:[],you:-1,code:this.code,host:false,pub:this.pub});
  }
  recordEnd(g){
    const humans=this.ids.filter(Boolean).length;if(!this.mgr.cfg.countBotGames&&humans<2)return;
    for(let i=0;i<4;i++){const id=this.ids[i];if(!id)continue;const team=i%2,win=g.end.w===team,st=g.seats[i]||{};
      this.mgr.store.record(id,{name:st.n,avatar:st.a,win,kap:this.track.kap[team],comeback:win&&this.track.maxDef[team]>=5,whitewash:!win&&g.sc[team]===0}).catch(e=>console.error('record failed',e))}
  }
  destroy(){this.H.destroy();for(const sk of [...this.sock,...this.spect])if(sk){sk.leave(this.code);sk.data.room=null;sk.emit('closed',{})}}
  summary(){const s=this.H.s;return{code:this.code,ph:s.ph,pub:this.pub,score:s.sc,round:s.rn,created:this.created,
    players:s.seats.map((x,i)=>x?(x.b!==undefined?{bot:true}:{name:x.n||'Player',online:!!this.sock[i],id:this.ids[i]}):null),watchers:this.spect.size}}
}

class Rooms{
  constructor(store,cfg){this.store=store;this.cfg=cfg||{countBotGames:true,maxRooms:3000};this.map=new Map();setInterval(()=>this.gc(),15000)}
  newCode(){let c;do{c=Array.from({length:5},()=>ALPH[rand(ALPH.length)]).join('')}while(this.map.has(c));return c}
  create(opts){if(this.map.size>=(this.cfg.maxRooms||3000))throw new Error('full');const r=new Room(this,this.newCode(),opts);this.map.set(r.code,r);return r}
  get(code){return this.map.get(code)}
  quick(settings){for(const r of this.map.values())if(r.pub&&r.H.s.ph==='lobby'&&r.connected()&&[1,2,3].some(i=>!r.H.s.seats[i]))return r;return this.create({pub:true,settings})}
  close(code){const r=this.map.get(code);if(r){r.destroy();this.map.delete(code)}}
  gc(){const now=Date.now();for(const [c,r] of this.map){const since=r.emptySince||r.created;if(!r.connected()&&now-since>(r.H.s.ph==='lobby'?30e3:120e3))this.close(c)}}
}
export {Rooms};
