'use strict';
// OMI LANKA game engine (server-authoritative). Same rules code the client uses offline.
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function pick(a){return a[rand(a.length)]}
const REPLY={'😢':'❤️','😲':'😎','😎':'🏆','🏆':'😎','😂':'😂','😡':'😂','❤️':'❤️','🤔':'😎'};
const TIME_SCALE=()=>globalThis.__OMI_TIME_SCALE||1;
const SUITS=['S','H','C','D'], RANKS=['7','8','9','10','J','Q','K','A'];
const SYM={S:'♠\uFE0E',H:'♥\uFE0E',D:'♦\uFE0E',C:'♣\uFE0E'};
const RED={H:1,D:1};
function rand(n){const a=new Uint32Array(1);crypto.getRandomValues(a);return a[0]%n}
const Omi={
  deck(){const d=[];for(const s of SUITS)for(const r of RANKS)d.push({s,r,id:r+s});return d},
  shuffle(a){const b=a.slice();for(let i=b.length-1;i>0;i--){const j=rand(i+1);[b[i],b[j]]=[b[j],b[i]]}return b},
  v(c){return RANKS.indexOf(c.r)},
  legal(hand,trick){if(!trick.length)return hand.slice();const led=trick[0].card.s;const f=hand.filter(c=>c.s===led);return f.length?f:hand.slice()},
  isLegal(hand,trick,card){return Omi.legal(hand,trick).some(c=>c.id===card.id)},
  beats(a,b,trump){if(a.s===b.s)return Omi.v(a)>Omi.v(b);return a.s===trump},
  winnerIdx(trick,trump){let w=0;for(let i=1;i<trick.length;i++)if(Omi.beats(trick[i].card,trick[w].card,trump))w=i;return w},
  scoreRound(tricks,callerTeam,cfg){
    if(tricks[0]===tricks[1])return{tie:true};
    const wt=tricks[0]>tricks[1]?0:1, kap=tricks[wt]===8;
    let pts=wt===callerTeam?1:2;
    if(kap){ if(cfg.kapothi==='game')pts=Infinity; else if(cfg.kapothi==='3')pts=3; }
    return{winnerTeam:wt,points:pts,kapothi:kap,byCaller:wt===callerTeam};
  }
};

/* funny comments [si, singlish, en] */
const C={
  start:[['ගේම පටන් ගමු! 💪','Game patan gamu! 💪','Let’s go! 💪'],['අද නම් අපි දිනනවා!','Ada nam api dinanawa!','We’re winning today!'],['කාඩ් හොඳට බෙදපන් හොඳේ 😂','Card hondata bedapan honde 😂','Deal me good cards, okay? 😂']],
  goodHand:[['අද නම් ගොඩ!','Ada nam goda!','Today’s a jackpot!'],['අම්මෝ! සුපිරි කාඩ් ටිකක්!','Ammo! Supiri card tikak!','Wow, what a hand!'],['අද මගේ දවස!','Ada mage dawasa!','Today is my day!'],['ගේම මගේ අතේ!','Game mage athe!','The game is in my hands!']],
  badMove:[['මොකක්ද බං ඒ දැම්මේ? 😂','Mokakda bang e damme? 😂','What did you just play, machan? 😂'],['කාඩ් ගහන්න දන්නෙ නැද්ද?','Card gahanna danne naddha?','Do you even know how to play?'],['අනේ අම්මෝ!','Ane ammo!','Oh my goodness!'],['ඒක නම් හිතාගන්න බෑ!','Eka nam hithaganna bae!','Never saw that coming!'],['පාට්නර්ගේ අතත් කපනවද? 🤦','Partnerge athath kapanawada? 🤦','Cutting your own partner? 🤦']],
  trickWin:[['අන්න වැඩ්ඩා!','Anna wadda!','That’s a master!'],['කොහොමද ඒක?','Kohomada eka?','How about that?'],['සුපිරි ගැහිල්ලක්!','Supiri gahillak!','Super shot!'],['දැන් තමයි ගේම!','Dan thamai game!','Now it’s a game!']],
  aceLost:[['A එකත් ගියා! අනේ අපොයි 😭','A ekath giya! Ane apoi 😭','Even the Ace is gone! 😭'],['ආස් එකක් කෑවා! 😂','Ace ekak kaewa! 😂','Somebody ate an Ace! 😂']],
  roundWin:[['ලකුණු ටික එනවා! 🔥','Lakunu tika enawa! 🔥','Points rolling in! 🔥'],['දැන් තමයි ගේම!','Dan thamai game!','Now it’s a game!'],['අපිව නවත්තන්න බෑ!','Apiwa nawaththanna bae!','Nobody can stop us!']],
  lose:[['අද නම් අපි ඉවරයි!','Ada nam api iwarai!','We’re done for today!'],['වාසනාව නැති දවසක්!','Waasanawa nathi dawasak!','Just not our lucky day!'],['ඊළඟ ගේමේ බලමු!','Eelanga game eke balamu!','We’ll see next game!'],['කාඩ් ටිකත් අපිට විරුද්ධයි!','Card tikath apita viruddhai!','Even the cards are against us!']],
  gameWin:[['කවුද දැන් වැඩ්ඩෝ?','Kawda dan waddo?','Who’s the boss now?'],['අන්න ඒකයි ගේම!','Anna ekai game!','Now THAT’s a game!'],['ජයග්‍රහණය අපේ!','Jayagrahanaya ape!','Victory is ours!'],['අද රෑ අපේ රෑ!','Ada rae ape rae!','Tonight is our night!']],
  kapothi:[['කපෝති! 🕊️ කවුද දැන් වැඩ්ඩෝ?','Kapothi! 🕊️ Kawda dan waddo?','Kapothi! 🕊️ Who’s the boss now?'],['අත් අටම අපේ! 😎','Ath atama ape! 😎','All eight tricks are ours! 😎']]
};

const BOTS=[
  {avatar:'uncle',names:['සුනිල් මාමා','Sunil Mama','Uncle Sunil']},
  {avatar:'sleepy',names:['නිදිමත නිමල්','Nidimatha Nimal','Sleepy Nimal']},
  {avatar:'champ',names:['චැම්පියන් චමින්ද','Champion Chaminda','Champion Chaminda']},
  {avatar:'angry',names:['කේන්ති කමල්','Kenthi Kamal','Grumpy Kamal']},
  {avatar:'village',names:['ගමේ ගුණේ','Game Gune','Village Gune']},
  {avatar:'cat',names:['පූසා පුංචි','Poosa Punchi','Punchi the Cat']},
  {avatar:'elephant',names:['අලියා අජිත්','Aliya Ajith','Ajith the Elephant']},
  {avatar:'cool',names:['කූල් චතුර','Cool Chathura','Cool Chathura']},
  {avatar:'kasun',names:['කසුන්','Kasun','Kasun']},
  {avatar:'dilini',names:['දිලිනි','Dilini','Dilini']},
  {avatar:'nuwan',names:['නුවන්','Nuwan','Nuwan']},
  {avatar:'sachini',names:['සචිනි','Sachini','Sachini']}
];

const Bot={
  chooseTrump(h){let best=h[0].s,bs=-1;for(const s of SUITS){const cs=h.filter(c=>c.s===s);if(!cs.length)continue;const sc=cs.length*10+cs.reduce((a,c)=>a+Omi.v(c),0)+rand(3);if(sc>bs){bs=sc;best=s}}return best},
  play(h,tr,T,seat){
    const legal=Omi.legal(h,tr),cost=c=>(c.s===T?20:0)+Omi.v(c);
    const low=a=>a.slice().sort((x,y)=>cost(x)-cost(y))[0],high=a=>a.slice().sort((x,y)=>cost(y)-cost(x))[0];
    if(!tr.length){
      const nonT=legal.filter(c=>c.s!==T),trumps=legal.filter(c=>c.s===T);
      const aces=nonT.filter(c=>c.r==='A');if(aces.length)return aces[0];
      if(trumps.length>=3&&trumps.some(c=>c.r==='A'||c.r==='K'))return high(trumps);
      if(nonT.length){const by={};nonT.forEach(c=>(by[c.s]=by[c.s]||[]).push(c));return low(Object.values(by).sort((a,b)=>b.length-a.length)[0])}
      return low(legal);
    }
    const wi=Omi.winnerIdx(tr,T),wc=tr[wi].card,led=tr[0].card.s;
    if(tr[wi].seat%2===seat%2)return low(legal);
    const winners=legal.filter(c=>Omi.beats(c,wc,T));
    if(winners.length){if(tr.length===3)return low(winners);const top=winners.filter(c=>c.s===led&&c.r==='A');return top.length?top[0]:low(winners)}
    return low(legal);
  }
};


function createHost(S,o){
  const SPD=()=>({slow:1.5,normal:1,fast:.55}[S.speed]||1)*TIME_SCALE();
function makeHost(o){
  const H={gen:0,ids:['me',null,null,null],pk:[null,null,null,null],lastSeq:[0,0,0,0],lastRx:[],offAt:[0,0,0,0],pending:null,contRes:null,contRej:null,lastSay:0,lastIdx:{},enc:[],hands:[[],[],[],[]],trick:[],pubTbl:!!o.pubTbl,lobbyEnd:o.pubTbl?Date.now()+25000:0,rbN:0,endN:0};
  const s=H.s={v:0,ph:o.lobby?'lobby':'start',seats:o.seats,sc:[0,0],cr:0,tg:S.target,kp:S.kapothi,dl:0,cl:null,tp:null,tu:null,tk:[],tr:[0,0],nc:[0,0,0,0],pt:[0,0,0,0],calls:[0,0,0,0],rn:0,cx:[0,-1],ev:[0],rb:null,end:null,tl:0,as:0};
  H.view=()=>JSON.parse(JSON.stringify(s));
  H.pub=()=>{s.v++;o.onPub(H)};
  H.isBot=i=>!!(s.seats[i]&&s.seats[i].b!==undefined);
  H.wait=async ms=>{const g=H.gen;await sleep(ms*SPD());if(g!==H.gen)throw'cancel'};
  H.later=(fn,ms)=>{const g=H.gen;setTimeout(()=>{if(g===H.gen){fn();H.pub()}},ms)};
  const bots=f=>[0,1,2,3].filter(i=>H.isBot(i)&&(!f||f(i)));
  H.speaker=f=>{const b=bots(f);return b.length?pick(b):-1};
  H.say=(seat,key,force)=>{const now=Date.now();if(!force&&now-H.lastSay<1800)return;H.lastSay=now;const arr=C[key];let i=rand(arr.length);if(arr.length>1&&i===H.lastIdx[key])i=(i+1)%arr.length;H.lastIdx[key]=i;s.ev=[s.ev[0]+1,seat,key,i]};
  H.rx=(seat,e)=>{if(seat>=0)s.ev=[s.ev[0]+1,seat,'@',e]};
  H.humanRx=(seat,e)=>{if(!REPLY[e]||Math.random()>=.45)return;const b=H.speaker(i=>i!==seat);if(b>=0)H.later(()=>H.rx(b,REPLY[e]),900+rand(600))};
  H.input=(seat,kind,val)=>{
    const p=H.pending;if(!p||p.seat!==seat||p.kind!==kind)return false;
    if(kind==='trump'){if(!SUITS.includes(val))return false;H.pending=null;p.res(val);return true}
    const card=H.hands[seat].find(c=>c.id===val);if(!card||!Omi.isLegal(H.hands[seat],H.trick,card))return false;
    H.pending=null;p.res(card);return true;
  };
  H.auto=()=>{const p=H.pending;if(!p)return;H.input(p.seat,p.kind,p.kind==='trump'?Bot.chooseTrump(H.hands[p.seat]):Bot.play(H.hands[p.seat],H.trick,s.tp,p.seat).id)};
  H.waitFor=(seat,kind)=>new Promise((res,rej)=>{H.pending={seat,kind,res,rej,t0:Date.now()}});
  H.abort=()=>{H.gen++;if(H.pending){const p=H.pending;H.pending=null;p.rej('cancel')}if(H.contRej){const r=H.contRej;H.contRej=H.contRes=null;r('cancel')}};
  H.destroy=()=>{H.abort();clearInterval(H.tickI)};
  H.cont=()=>{if(H.contRes)H.contRes()};
  H.tickI=setInterval(()=>{
    const p=H.pending;
    if(p){const st=s.seats[p.seat];const off=st&&st.h&&!st.on&&Date.now()-H.offAt[p.seat]>8000;if((S.timer&&Date.now()-p.t0>30500)||off)H.auto()}
    if(s.ph==='lobby'&&H.pubTbl){const rem=Math.max(0,Math.ceil((H.lobbyEnd-Date.now())/1000));if(rem===0||[1,2,3].every(i=>s.seats[i]))H.start();else if(rem!==s.as){s.as=rem;H.pub()}}
  },400);
  H.start=()=>{
    const used=new Set(s.seats.filter(Boolean).map(x=>x.a));
    const pool=Omi.shuffle(BOTS.map((b,i)=>i).filter(i=>!used.has(BOTS[i].avatar)));const isC=i=>['kasun','dilini','nuwan','sachini'].includes(BOTS[i].avatar)?1:0;pool.sort((a,b)=>isC(a)-isC(b));
    for(let i=1;i<4;i++)if(!s.seats[i])s.seats[i]={b:pool.pop()};
    H.run();
  };
  H.deal=async(deck,start,n)=>{let idx=start;for(let i=0;i<4;i++){const seat=(s.cl+i)%4;H.hands[seat].push(...deck.slice(idx,idx+n));idx+=n;s.nc[seat]+=n;H.pub();await H.wait(n*55+170)}await H.wait(250)};
  H.trickTalk=(w,done)=>{
    const ace=done.find(x=>x.card.r==='A'&&x.seat!==w);
    if(ace&&Math.random()<.55){H.say(H.speaker(i=>i!==ace.seat),'aceLost');return}
    if(!H.isBot(w)){const pt=(w+2)%4;if(H.isBot(pt)&&Math.random()<.5)H.say(pt,'trickWin');else if(Math.random()<.35)H.rx(H.speaker(i=>i%2!==w%2),pick(['😢','😡','🤔']))}
    else if(Math.random()<.28)H.say(w,'trickWin');else if(Math.random()<.2)H.rx(w,'😎');
  };
  H.round=async()=>{
    s.rn++;H.hands=[[],[],[],[]];H.trick=[];s.nc=[0,0,0,0];s.tk=[];s.tr=[0,0];s.tp=null;s.cl=(s.dl+1)%4;s.tu=null;s.ph='deal';s.rb=null;H.pub();
    const deck=Omi.shuffle(Omi.deck());
    await H.deal(deck,0,4);
    s.ph='trump';s.tu=s.cl;s.tl=H.isBot(s.cl)?0:(S.timer?30000:0);H.pub();
    let tp;if(H.isBot(s.cl)){await H.wait(1300);tp=Bot.chooseTrump(H.hands[s.cl])}else tp=await H.waitFor(s.cl,'trump');
    s.tp=tp;s.calls[s.cl]++;s.tu=null;s.ph='deal';H.pub();await H.wait(1300);
    await H.deal(deck,16,4);
    const strong=bots(i=>{const h=H.hands[i];return h.filter(c=>c.s===tp).length*2+h.filter(c=>c.r==='A').length>=7});
    if(strong.length&&Math.random()<.7)H.say(pick(strong),'goodHand');
    s.ph='play';let leader=s.cl;
    for(let n8=0;n8<8;n8++){
      H.trick=[];s.tk=[];
      for(let k=0;k<4;k++){
        const seat=(leader+k)%4,bot=H.isBot(seat);s.tu=seat;s.tl=bot?0:(S.timer?30000:0);H.pub();
        let card;if(bot){await H.wait(650+rand(550));card=Bot.play(H.hands[seat],H.trick,tp,seat)}else card=await H.waitFor(seat,'play');
        if(!Omi.isLegal(H.hands[seat],H.trick,card))card=Omi.legal(H.hands[seat],H.trick)[0];
        const prev=H.trick.length?H.trick[Omi.winnerIdx(H.trick,tp)]:null;
        H.hands[seat]=H.hands[seat].filter(c=>c.id!==card.id);s.nc[seat]--;H.trick.push({seat,card});s.tk.push([seat,card.id]);
        if(prev&&prev.seat!==seat&&prev.seat%2===seat%2&&card.s===tp&&H.trick[0].card.s!==tp&&Omi.beats(card,prev.card,tp)){
          const sp=H.isBot((seat+2)%4)?(seat+2)%4:H.speaker(i=>i!==seat);H.later(()=>H.say(sp,'badMove',true),450);
        }
        s.tu=null;
        H.pub();await H.wait(380);
      }
      await H.wait(900);
      const w=H.trick[Omi.winnerIdx(H.trick,tp)].seat;s.tr[w%2]++;s.pt[w]++;
      H.trickTalk(w,H.trick);s.cx=[s.cx[0]+1,w];s.tk=[];H.pub();await H.wait(900);leader=w;
    }
    const res=Omi.scoreRound(s.tr,s.cl%2,{kapothi:s.kp});H.rbN++;const rb={n:H.rbN,t:s.tr.slice()};
    if(res.tie){s.cr+=1;Object.assign(rb,{tie:1,cr:s.cr})}
    else{
      let p=res.points===Infinity?Math.max(s.tg-s.sc[res.winnerTeam],1):res.points;const carry=s.cr;s.cr=0;p+=carry;s.sc[res.winnerTeam]+=p;
      Object.assign(rb,{wt:res.winnerTeam,p,kap:res.kapothi?1:0,byC:res.byCaller?1:0,carry});
      H.say(H.speaker(i=>i%2===res.winnerTeam),res.kapothi?'kapothi':'roundWin',true);
      const lb=H.speaker(i=>i%2!==res.winnerTeam);if(lb>=0)H.later(()=>H.say(lb,'lose',true),1600);
    }
    s.rb=rb;s.ph='round';s.tu=null;H.pub();
    await new Promise((res2,rej)=>{const to=setTimeout(()=>{H.contRes=H.contRej=null;res2()},6500*SPD());H.contRes=()=>{clearTimeout(to);H.contRes=H.contRej=null;res2()};H.contRej=e=>{clearTimeout(to);rej(e)}});
  };
  H.run=async()=>{
    H.abort();
    Object.assign(s,{sc:[0,0],cr:0,dl:rand(4),rn:0,pt:[0,0,0,0],calls:[0,0,0,0],end:null,rb:null,tk:[],tr:[0,0],nc:[0,0,0,0],tp:null,tu:null,cl:null,ph:'start',tg:S.target,kp:S.kapothi,as:0,tl:0});
    H.hands=[[],[],[],[]];H.trick=[];H.pub();
    H.later(()=>H.say(H.speaker(),'start',true),900);
    try{
      await H.wait(1900);
      while(true){
        await H.round();
        if(s.sc[0]>=s.tg||s.sc[1]>=s.tg){H.endN++;s.ph='end';s.end={n:H.endN,w:s.sc[0]>s.sc[1]?0:1};s.tu=null;H.pub();return}
        s.dl=(s.dl+1)%4;
      }
    }catch(e){if(e!=='cancel')console.error(e)}
  };
  return H;
}

  return makeHost(o);
}
const AVATARS=['kasun','dilini','nuwan','sachini','uncle','champ','sleepy','angry','cool','village','cat','elephant'];
const REACTS=Object.keys(REPLY);
export {Omi,Bot,createHost,AVATARS,REACTS,BOTS,rand};
